function x = read_wind_filesync_data()

dirRoot = [getDir('Production') '\'];
SqlTables = { 
%     'WDS0003' 'ChangeWindCode' '' '' '';
%     'WDS0018' 'SHScMembers' '' '' '';
%     'WDS0019' 'SZScMembers' '' '' '';
%     'WDS0102' 'AShareEXRightDividendRecord' '' '' '';
%     'WDS0102' 'AShareTradingSuspension' '' '' '';
%     'WDS0102' 'AShareEodPrices'    'TRADE_DT' '20181225' '20190630';
%     'WDS0102' 'AShareEodPrices'    'TRADE_DT' '20190630' '20191231';
%     'WDS0102' 'AShareEodPrices'    'TRADE_DT' '20191231' '20200630';
%     'WDS0102' 'AShareEodPrices'    'TRADE_DT' '20200630' '20201231';
%     'WDS0103' 'AShareL2Indicators' 'TRADE_DT' '20181225' '20190630';
%     'WDS0103' 'AShareL2Indicators' 'TRADE_DT' '20190630' '20191231';
    'WDS0103' 'AShareL2Indicators' 'TRADE_DT' '20191231' '20200630';
    'WDS0103' 'AShareL2Indicators' 'TRADE_DT' '20200630' '20201231';
    'WDS0103' 'AShareMoneyFlow'    'TRADE_DT' '20181225' '20190231'; 
    'WDS0103' 'AShareMoneyFlow'    'TRADE_DT' '20190231' '20190431'; 
    'WDS0103' 'AShareMoneyFlow'    'TRADE_DT' '20190431' '20190631'; 
    'WDS0103' 'AShareMoneyFlow'    'TRADE_DT' '20190631' '20190831';
    'WDS0103' 'AShareMoneyFlow'    'TRADE_DT' '20190831' '20191031'; 
    'WDS0103' 'AShareMoneyFlow'    'TRADE_DT' '20191031' '20191231';
    'WDS0103' 'AShareMoneyFlow'    'TRADE_DT' '20191231' '20200231';
    'WDS0103' 'AShareMoneyFlow'    'TRADE_DT' '20200231' '20200431';
    'WDS0103' 'AShareMoneyFlow'    'TRADE_DT' '20200431' '20200631'; 
    'WDS0103' 'AShareMoneyFlow'    'TRADE_DT' '20200631' '20200831';
    'WDS0103' 'AShareMoneyFlow'    'TRADE_DT' '20200831' '20201031'; 
    'WDS0103' 'AShareMoneyFlow'    'TRADE_DT' '20201031' '20201231';
    'WDS0104' 'AShareMarginTrade' '' '' '';
    'WDS0105' 'AShareCompRestricted' '' '' '';
    'WDS0105' 'AShareDividend' '' '' '';
    'WDS0105' 'AShareEventDateInformation' '' '' '';
    'WDS0105' 'AShareFreeFloat' '' '' '';
    'WDS0105' 'AShareFreeFloatCalendar' '' '' '';
    'WDS0105' 'AShareCapitalization' '' '' '';
    'WDS0105' 'AShareRightIssue' '' '' '';
    'WDS0105' 'AShareSEO' '' '' '';
    'WDS0105' 'AShareStockRepo' '' '' '';
    'WDS0106' 'AShareAuditOpinion' '' '' '';
    'WDS0106' 'AShareBalanceSheet' '' '' '';
    'WDS0106' 'AShareCashFlow' '' '' '';
    'WDS0106' 'AShareIncome' '' '' '';
    'WDS0106' 'AShareIssuingDatePredict' '' '' '';
    'WDS0106' 'AShareProfitNotice' '' '' '';
    'WDS0106' 'AShareProfitExpress' '' '' '';
    'WDS0106' 'AShareANNFinancialIndicator' '' '' '';
    'WDS0106' 'AShareFinancialIndicator' '' '' '';
    'WDS0106' 'AShareTTMAndMRQ' '' '' '';
    'WDS0106' 'AShareTTMHis' '' '' '';
    'WDS0107' 'FinNotesDetail' '' '' '';
    'WDS0107' 'Top5ByOperatingIncome' '' '' '';
    'WDS0107' 'AShareSalesSegment' '' '' '';
    'WDS0108' 'AShareManagement' '' '' '';
    'WDS0108' 'AShareManagementHoldReward' '' '' '';
    'WDS0108' 'AShareStaff' '' '' '';
    'WDS0108' 'AShareStaffStructure' '' '' '';
    'WDS0109' 'ASarePlanTrade' '' '' '';
    'WDS0109' 'AShareInsideHolder' '' '' '';
    'WDS0109' 'AShareInsiderTrade' '' '' '';
    'WDS0110' 'AShareIllegality' '' '' '';
    'WDS0110' 'AShareRegInv' '' '' '';
    'WDS0110' 'AShareST' '' '' '';
    'WDS0111' 'CommitProfitSummary' '' '' '';
    'WDS0112' 'AShareISActivity' '' '' '';
    'WDS0112' 'AShareISParticipant' '' '' '';
    'WDS0198' 'AIndexMembersCITICS' '' '' '';
    'WDS0198' 'AShareIndustriesClassCITICS'  '' '' '';
    'WDS0198' 'SWIndexMembers' '' '' '';
    'WDS0202' 'AShareEarningEst' 'EST_DT' '20181225' '20190231';
    'WDS0202' 'AShareEarningEst' 'EST_DT' '20190231' '20190431';
    'WDS0202' 'AShareEarningEst' 'EST_DT' '20190431' '20190631';
    'WDS0202' 'AShareEarningEst' 'EST_DT' '20190631' '20190831';
    'WDS0202' 'AShareEarningEst' 'EST_DT' '20190831' '20191031';
    'WDS0202' 'AShareEarningEst' 'EST_DT' '20191031' '20191231'; 
    'WDS0202' 'AShareEarningEst' 'EST_DT' '20191231' '20200231'; 
    'WDS0202' 'AShareEarningEst' 'EST_DT' '20200231' '20200431';
    'WDS0202' 'AShareEarningEst' 'EST_DT' '20200431' '20200631';
    'WDS0202' 'AShareEarningEst' 'EST_DT' '20200631' '20200831';
    'WDS0202' 'AShareEarningEst' 'EST_DT' '20200831' '20201031'; 
    'WDS0202' 'AShareEarningEst' 'EST_DT' '20201031' '20201231';
    'WDS0202' 'AShareIPOPricingForecast' '' '' '';
    'WDS0202' 'AShareStockRating' '' '' '';
    'WDS0502' 'CFuturesWarehouseStocks' '' '' '';
}';

% Sq1Tab1es = {'WDS0109' 'AShareInsideHolder' '' '' ''};

for tble = SqlTables
    sqltble = tble{2};  tic;
    if strcmp(tble{3},'')
%      sqlstmt = ['SELECT TOP 100 * FROM WindFileSync.' upper(sqltble)];
       sqlstmt = ['SELECT TOP 100 * FROM [WindFileSync].[dbo].[' upper(sqltble) ']'];
    else
       sqlstmt = ['SELECT TOP 100 * FROM [WindFileSync].[dbo].[' upper(sqltble) ']'  newline ... 
                  ' WHERE ' tble{3} '>' tble{4} ' and ' tble{3} '<=' tble{5}];
    end
    disp([newline sqlstmt]);
    x = DataBaseFetcher.getDataFromWind(sqlstmt,2);
    disp([sqltble repmat(' ',1,35-length(sqltble)) ' ---> finished #rows:' num2str(size(x,1)) '  in ' num2str(toc) ' sec']);
    if numel(x)>0
       eval([sqltble ' = x;']);
       if strcmp(tble{3},'')
          save([dirRoot tble{1} '-' sqltble '.mat'], sqltble);
       else
          save([dirRoot tble{1} '-' sqltble '-' tble{3} '(' tble{4} '-' tble{5} ').mat'], sqltble);
       end
       clear(sqltble); 
    end
end


Sq1Tab1es = { % S_INFO_NAME	not like '%??%' or locate('??',S_INFO_NAME)=0 are not supported for Chinese Characters in JDBC, but are in MySQL Workbench
   	 	 'WDS0013', 'WindCustomCode', ...
	    ['SELECT * FROM WindFileSync.' upper('WindCustomCode') ' WHERE CRNCY_CODE = ''CNY'' and  ' newline ...
         'S_INFO_SECURITIESTYPES = ''A'' OR S_INFO_EXCHMARKET = ''SSE'' OR S_INFO_EXCHMARKET = ''SZSE'' S_INFO_EXCHMARKET =?''CFFEX'' ' newline ...
         ' OR S_INFO_EXCHMARKET = ''SHFE'' OR S_INFO_EXCHMARKET = ''CZCE'' OR S_INFO_EXCHMARKET = ''DCE'') '];
         'WDS0106', 'AShareAuditDescription', ...
	    ['SELECT Tl.*, T2.S_INFO_WINDCODE FROM 	WindFileSync.' upper('AShareAuditDescription') ' as T1 ' newline ... 
         'LEFT JOIN (SELECT S_INFO_COMPCODE, S_INFO_WINDCODE FROM WHERE S_INFO_SECURITIESTYPES =''A"") as T2 ' newline ...
         ' ON TI.S_INFO_COMPCODE = T2.S_INFO_COMPCODE'];
         'WDS0106', 'AShareAccountingChange', ...
        ['SELECT Tl.*, T2.S_INFO_WINDCODE FROM WindFileSync.' upper('AShareAccountingChange') ' as Tl ' newline ...
         'LEFT JOIN (SELECT S_INFO_COMPCODE, S_INFO_WINDCODE FROM WHERE S_INFO_SECURITIESTYPES =''A"") as T2 ' newline ...
         ' ON TI.S_INFO_COMPCODE = T2.S_INFO_COMPCODE'];
         'WDS0106', 'AShareFinancia1Derivative', ...
        ['SELECT Tl.*, T2.S_INFO_WINDCODE FROM WindFileSync.' upper('AShareFinancia1Derivative') ' as TI ' newline ...
         'LEFT JOIN (SELECT S_INFO_COMPCODE, S_INFO_WINDCODE FROM WHERE S_INFO_SECURITIESTYPES =''A"") as T2 ' newline ...
         ' ON TI.S_INFO_COMPCODE = T2.S_INFO_COMPCODE'];
         'WDS0106', 'AShareReportPeriodIndex', ...
        ['SELECT Tl.*, T2.S_INFO_WINDCODE FROM WindFileSync.' upper('AShareReportPeriodIndex') ' as T1 ' newline ...
         'LEFT JOIN (SELECT S_INFO_COMPCODE, S_INFO_WINDCODE FROM WHERE S_INFO_SECURITIESTYPES =''A"") as T2 ' newline ...
         ' ON TI.S_INFO_COMPCODE = T2.S_INFO_COMPCODE'];
         'WDS0107', 'AShareGoodWill', ...
        ['SELECT Tl.*, T2.S_INFO_WINDCODE FROM WindFileSync.' upper('AShareGoodWill') ' as T1 ' newline ...
         'LEFT JOIN (SELECT S_INFO_COMPCODE, S_INFO_WINDCODE FROM WHERE S_INFO_SECURITIESTYPES =''A"") as T2 ' newline ...
         ' ON TI.S_INFO_COMPCODE = T2.S_INFO_COMPCODE'];
         'WDS0107', 'AShareGoodWillDeVa1ue', ...
        ['SELECT Tl.*, T2.S_INFO_WINDCODE FROM WindFileSync.' upper('AShareGoodWillDeVa1ue') ' as T1 ' newline ...
         'LEFT JOIN (SELECT S_INFO_COMPCODE, S_INFO_WINDCODE FROM WHERE S_INFO_SECURITIESTYPES =''A"") as T2 ' newline ...
         ' ON TI.S_INFO_COMPCODE = T2.S_INFO_COMPCODE'];
         'WDS0107', 'AShareRDexpenditure', ...
        ['SELECT Tl.*, T2.S_INFO_WINDCODE FROM WindFileSync.' upper('AShareRDexpenditure') ' as T1 ' newline ...
         'LEFT JOIN (SELECT S_INFO_COMPCODE, S_INFO_WINDCODE FROM WHERE S_INFO_SECURITIESTYPES =''A"") as T2 ' newline ...
         ' ON TI.S_INFO_COMPCODE = T2.S_INFO_COMPCODE'];
         'WDS0107', 'AShareRDExpense', ...
        ['SELECT Tl.*, T2.S_INFO_WINDCODE FROM WindFileSync.' upper('AShareRDExpense') ' as T1 ' newline ...
         'LEFT JOIN (SELECT S_INFO_COMPCODE, S_INFO_WINDCODE FROM WHERE S_INFO_SECURITIESTYPES =''A"") as T2 ' newline ...
         ' ON TI.S_INFO_COMPCODE = T2.S_INFO_COMPCODE'];
         'WDS0115', 'AIndexEODPrices', ...
        ['SELECT * FROM WindFileSync.' upper('AIndexEODPrices') newline ...
	     ' WHERE S_INFO_WINDCODE in	(''OOOO01.SH'',''OOOO09.SH'',''OOOO10.SH'',''OOOO16.SH'',''000300.SH'',''000852.SH'') '  newline ...
	     '    OR S_INFO_WINDCODE in	(''HOOO01.SH'',''HOOO09.SH'',''HOOO10.SH'',''HOOO16.SH'',''H00300.SH'',''H00852.SH'') '  newline ...
	     '    OR S_INFO_WINDCODE in	(''OOO903.SH'',''OO0904.SH'',''OO0905.SH'',''OOO906.SH'',''000907.SH'',''881001.WI'') '  newline ...
	     '    OR S_INFO_WINDCODE in	(''399005.SZ'',''399006.SZ'',''399300.SZ'',''399330.SZ'',''399903.SZ'',''399904.SZ'',''399905.SZ'',''399906.SZ'',''399907.SZ'') '  newline ...
	     '    OR S_INFO_WINDCODE in	(''HOO903.CSI'',''HOO904.CSI'',''HOO905.CSI'',''HOO906.CSI'',''HOO907.CSI'',''H00300.CSI'') '  newline ...
	     '    OR (S_INFO_WINDCODE >= ''801010.SI''   and  S_INFO_WINDCODE <= ''801890.SI'') '  newline ...
	     '    OR (S_INFO_WINDCODE >= ''CI005000.WI'' and  S_INFO_WINDCODE <= ''CI005030.WI'') ']'
         };

Sq1Tab1es = {};
for tble = SqlTables
    sqltble = tble{2};  sqlstmt = tble{3};  tic;
    disp([newline sqlstmt]);
    x = DataBaseFetcher.getDataFromWind(sqlstmt,2);
    disp([sqltable repmat(' ',1,35-length(sqltable)) ' ---> finished #rows:' num2str(size(x,1)) '  in ' num2str(toc) ' sec']);
    if numel(x)>0
       eval([sqltble ' = x;']);
       save([dirRoot tble{1} '-' sqltble '.mat'], sqltble);
       clear(sqltble); 
    end
end

end