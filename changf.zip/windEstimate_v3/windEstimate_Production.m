% Download  1571_yyyymmdd.csv  into  \\PINFU-WS-01\Production\DataCSV
% cd('\\PINFU-WS-01\Production\zhangf\windEstimate');

%update_wdbTable1571_v2(3);  

tic
dirRoot = getDir('Production');       dirData = [dirRoot '\Data\data2github']; 

disp(['\r windAnalyst_Data \n' datestr(now(),'yyyymmdd HH:MM:SS') '\t']);


if 1 == 1%data source: sql Data  
    
    update_wdbTable1571_v2(3);    
    windAnalyst_Data(datestr(today()-5,'yyyymmdd'), datestr(today(),'yyyymmdd'), 1);  % today()-4  

elseif 1 == 0%data source: DataCsv  
    
    %ɨ������wind_consensus�ļ��Ƿ����  
    start = 0;  
    while(start == 0)  
        if exist([dirRoot '\DataCsv\1571_' datestr(today(),'yyyymmdd') '.csv'],'file') ~= 0
            disp(['##### �����ļ��Ѵ���,��ʼ����: ' datestr(now(),'yyyymmdd HH:MM:SS')]);
            start = 1;
            pause(15);
        else
            disp(['---- �����ļ���δ�յ�,�����ȴ�: ' datestr(now(),'yyyymmdd HH:MM:SS')]);
            pause(30);
        end
    end

    %
    fileinfo = dir([dirRoot '\DataCsv\1571_' datestr(now(),'yyyymmdd') '.csv']);
    if hour(fileinfo.datenum)*60+minute(fileinfo.datenum) >= 9*60+20
        disp('csv�ѳ������뼯�Ͼ���ʱ�䣬�ʲ���copy csv��production');
    else
        disp('csv��δ�������뼯�Ͼ���ʱ�䣬��copy csv��production');
        dirCopy = 'copy \\PINFU-WS-01\Production\DataCsv\';
        system([dirCopy '1571_' datestr(today(),'yyyymmdd') '.csv '      '\\PINFU-WS-01\Production\DataCsv_production']);
        system([dirCopy '1569_' datestr(today(),'yyyymmdd') '.csv '      '\\PINFU-WS-01\Production\DataCsv_production']);
    end

    % Update analysts table  windAnalystTable.mat
    windAnalyst_Data(datestr(today()-5,'yyyymmdd'), datestr(today()+1,'yyyymmdd'), 2);  % today()-4
    
end

Years = 2020:2022;
for y=Years;  dlmwrite([dirData '\wConsensusFY' num2str(y) '_status.txt'], [1,0,0,0]);  end  % 2004:2021

ftr1 = 'wind_Analyst_Consensus_yyyy'; 
ftr2 = 'wind_Analyst_Factors_yyyy'; 
for yyyy = Years
    disp(   ['matlab.exe -nosplash -nodesktop -minimize -r "' ftr1 '(' num2str(yyyy) ');' ftr2 '(' num2str(yyyy) '); exit;" &']);
    system( ['matlab.exe -nosplash -nodesktop -minimize -r "' ftr1 '(' num2str(yyyy) ');' ftr2 '(' num2str(yyyy) '); exit;" &']);
end

disp(['\r wind_Analyst_Factors_FY0123 \n' datestr(now(),'yyyymmdd HH:MM:SS') '\t']);
% Wait for all years finished Combine Factors into calendar year Time Series % 2005:2019
wind_Analyst_Factors_FY0123(2020:2020);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

system('taskkill /F /IM EXCEL.EXE');
pause(5);

disp(['\r Model_Forecast_Wind_AII_v1a \n' datestr(now(),'yyyymmdd HH:MM:SS') '\t']);  % calculate model scores

system( ['matlab.exe -nosplash -nodesktop -minimize -r " cd(''\\pinfu-ws-01\production\factors_lqy\windEstimate_v2_300\''); Model_Forecast_Wind_AII_v2b_300; exit;" &']);   %300ָ��ģ��

Model_Forecast_Wind_AII_v4_merge;

disp(['\r Done \n' datestr(now(),'yyyymmdd HH:MM:SS') '\t']);
toc



