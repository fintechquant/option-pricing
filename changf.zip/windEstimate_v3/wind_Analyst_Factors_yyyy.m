function wind_Analyst_Factors_yyyy(yyyy)                                    % 2004:2020

    dirRoot = getDir('Production');    dirData = [dirRoot '\Data\data2github'];         % 'Production'  'D:\PinFu-WS-01\Production'
    
    load([dirData '\BroksMap.mat']);
    load([dirData '\windAnalystTable.mat']);              
    idx = find(windAnalystTable.F4_1571==yyyy*10000+1231);
    windAnalystTable = windAnalystTable(idx,:);
    windAnalystTable(datenum(num2str(cell2mat(windAnalystTable.upDate)),'yyyymmdd')-datenum(num2str(windAnalystTable.F5_1571),'yyyymmdd')>14,:) = [];
    Brokers  = unique(windAnalystTable.BrokerMap);
    year1231 =        windAnalystTable.F4_1571;   
    broker   =        windAnalystTable.BrokerMap;
    firstime =        windAnalystTable.firstime;
    lasttime =        windAnalystTable.lasttime;

    Year = num2str(yyyy);                                                   % Fiscal Year
    status = 0;
    while status(1)==0
        pause(1);   status = dlmread([dirData '\wConsensusFY' Year '_status.txt']);    % status=0 not ready to read;  status=1 ready to read & write 
    end
    load([dirData '\wConsensusFY' Year '.mat']);

    Dim1 = [datenum(yyyy-2,1,1) : min([today() datenum(yyyy+1,5,1)])]';     % Dim1 = wConsensus.NIs.avg.Dim1;      
    Dim2 = wConsensus.NIs.avg.Dim2;
    Vars = {'NIs'};                                                         % {'EPS','NIs','Rev'};

    for var = Vars
        Lag1D.(var{:}) = tshift(wConsensus.(var{:}).avg, -1);           % Lag1D.(var{:}) = tshift(wConsNIs.(['Y' Year]),-1);
        Lag1D.(var{:}) = subset(Lag1D.(var{:}), Dim1, Dim2);
    end
    
    wConsTV.EPS = 0;    wConsTV.Rev = 0;    wConsTV.NIs = 0;
    wConsNo.EPS = 0;    wConsNo.Rev = 0;    wConsNo.NIs = 0; 
    tic;
    for brk = Brokers'
%       idx   = find(year1231==yyyy*10000+1231 & broker==brk);        
%       idx   = find(year1231==yyyy*10000+1231 & broker==brk & (isnan(lasttime)|lasttime>60));           % isnan(lasttime) | lasttime>60
        idx   = find(broker==brk & (isnan(lasttime)|lasttime>60));                                       % isnan(lasttime) | lasttime>60
        yrbrk = [Year '1231 ' BroksMap{brk,2}];       display([num2str(brk) ' ' yrbrk '  ' num2str(numel(idx)) ' ' num2str(toc)]);
        if  numel(idx)>0
            wind.EPS1 = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17  7])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.EPS2 = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17  8])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.EPS3 = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17  9])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.NI1  = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17 10])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.NI2  = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17 11])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.Rev  = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17 12])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.SHRs = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17 14])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.EPS  = iff(~isnan(wind.EPS1), wind.EPS1, wind.EPS2);
            wind.EPS  = iff(~isnan(wind.EPS),  wind.EPS,  wind.EPS3);
%           wind.NIs  = iff(~isnan(wind.NI1),  wind.NI1,  wind.NI2);
            wind.NIs  = iff(~isnan(wind.NI2),  wind.NI2,  wind.NI1);
            wind.NIs  = iff(~isnan(wind.NIs),  wind.NIs,  wind.EPS*wind.SHRs);
            wind.EPS  = iff(~isnan(wind.EPS),  wind.EPS,  wind.NIs/wind.SHRs);
            for var = Vars                                                  % {'EPS','NIs','Rev'}
                var = var{:};
                TempL0 = subset(wind.(var),             Dim1, Dim2);
                TempL1 = ttlast(wind.(var), {-9999,-1}, Dim1, Dim2);
                Temp   = iff(isnan(TempL1) & ~isnan(TempL0),     TempL0/Lag1D.(var)-1, NaN);     % �״�һ��Ԥ��
                Temp   = iff(TempL0>TempL1 & TempL0>Lag1D.(var), TempL0/Lag1D.(var)-1, Temp);    % �ϵ� ����һ��Ԥ��
                Temp   = iff(TempL0<TempL1 & TempL0<Lag1D.(var), TempL0/Lag1D.(var)-1, Temp);    % �µ� ����һ��Ԥ��
                wConsTV.(var) = wConsTV.(var) + iff(isnan(Temp), 0, Temp);
                wConsNo.(var) = wConsNo.(var) + iff(isnan(Temp), 0, 1);
            end
        end
    end % brk
    
    status = [0 0 0 0];
    while ~isequal(status([1 3]),[1 1])                                     % require wind_Analyst_Consensus_yyyy completed for f2 to be computed correctly;
        pause(1);   status = dlmread([dirData '\wConsensusFY' Year '_status.txt']);    % status=0 not ready to read else ready to read & write 
    end
    dlmwrite([dirData '\wConsensusFY' Year '_status.txt'], [0 status(2) 1 0]);         % lock the file  

    for var = Vars
        var = var{:};
%       wConsFtr1Y.(var{:}).(['Y' Year]) = iff(wConsNo.(var{:})>0, wConsTV.(var{:})/wConsNo.(var{:}), NaN);   
        Temp1 = iff(wConsNo.(var)>0, wConsTV.(var)/wConsNo.(var), 0);
%       Temp1 = subset(tcumsum(iff(isnan(Temp1),0,Temp1)), Dim1, Dim2);
%       Temp2 = subset(tcumsum(wConsNo.(var{:})),          Dim1, Dim2);
        Temp1 = tcumsum(iff(isnan(Temp1),0,Temp1));
        Temp2 = tcumsum(wConsNo.(var));
        Temp1 = Temp1 - tshift(Temp1,-1);
        Temp2 = Temp2 - tshift(Temp2,-1);
        wConsensus.(var).f1 = iff(Temp2==0, NaN, Temp1);                    % 1st factor:  ����һ��Ԥ�� ����һ��Ԥ�� revision
        wConsensus.(var).n1 = iff(Temp2==0, NaN, Temp2);
        Temp1 = (wConsensus.(var).avg - tshift(wConsensus.(var).avg, -10)) / abs(tshift(wConsensus.(var).avg, -10)) + 1;
%       Temp1 = wConsensus.(var).avg / tshift(wConsensus.(var).avg, -10);
        wConsensus.(var).f2 = subset(Temp1, Dim1, Dim2);                    % 2nd factor:  Simple revision
    end
    save([dirData '\wConsensusFY' Year '.mat'], 'wConsensus');                   % display([dirData 'wConsensusFY' Year '.mat Factors saved']);
    dlmwrite([dirData '\wConsensusFY' Year '_status.txt'], [1 status(2) 1 1]);   % unlock the file
    
end
