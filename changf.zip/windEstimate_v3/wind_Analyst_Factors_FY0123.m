function wind_Analyst_Factors_FY0123(Years)
% wind_Analyst_Factors(2018:2029)   combine Ftrs by Calendar year 2005:2019

    dirRoot = getDir('Production');   dirData = [dirRoot '\Data\data2github'];         % Production  D:\PinFu-WS-01\Production
 
    for yyyy = Years(1)-1:Years(end)+2
        status = [0 0 0 0];
        while ~isequal(status, [1 0 1 1])  %��v1�汾��[1 0 1 0]  �ϰ汾��[1 0 1 1]
           pause(1);  status = dlmread([dirData '\wConsensusFY' num2str(yyyy) '_status.txt']);
        end
    end
    
%     Vars = {'NIs','f1'; 'NIs','f2'; 'NIs','avg'; 'NIs','num'; 'NIs','n1'};  % {'EPS','NIs','Rev'}; {'NIs','f1'; 'NIs','f2'; 'Rev','f1'};
    Vars = {'NIs','f1'; 'NIs','f2'; 'NIs','avg';};  % {'EPS','NIs','Rev'}; {'NIs','f1'; 'NIs','f2'; 'Rev','f1'};
%     Vars = {'NIs','num'};
    for yyyy = Years(1)-1:Years(end)+2                                      % Years  % 2005:2019
        try
            load([dirData '\wConsensusFY' num2str(yyyy) '.mat']);
            wCons.(['FY' num2str(yyyy)]) = wConsensus;
            disp([dirData '\wConsensusFY' num2str(yyyy) '.mat loaded']);
        catch
            disp([dirData '\wConsensusFY' num2str(yyyy) '.mat not found']);
        end
    end
    clear wConsensus;                                                       % wConsensus ���� ��λ�� ������wConsensusFY0123

    if  1==0                                                                % if 1=0: start from the begining;  else: incremental update
        Temp = compact(TdT(' ', 'merge', {20151111,'S',NaN}, 'mattbl','tbl', 'type', {'date','cell','double'}));
        for i = 1:size(Vars,1)
            for t = 0:3
                wConsensus.(Vars{i,1}).(Vars{i,2}).(['FY' num2str(t)]) = Temp;     % FY0, FY1, FY2, FY3
            end
        end
    else                                                                    % incremental update
        try
            load([dirData '\wConsensusFY0123.mat']);
        catch
            error(['file ' dirData '\wConsensusFY0123.mat does not exist']);
        end
    end

    for yyyy = Years                                                        % Calendar Years  % 2005:2019
        yyyy
        FY0 = ['FY' num2str(yyyy-1)];   FY1 = ['FY' num2str(yyyy+0)];  
        FY2 = ['FY' num2str(yyyy+1)];   FY3 = ['FY' num2str(yyyy+2)];  
        Dim2 = union(wCons.(FY0).NIs.avg.Dim2, wCons.(FY1).NIs.avg.Dim2);
        Dim1 = wCons.(FY1).NIs.avg.Dim1;   Dim1 = Dim1(year(Dim1)==yyyy);
        if yyyy <= 2022
%           Temp  = iff(isnan(subset(wCons.(FY1).NIs.avg, Dim1(Dim1==datenum(yyyy,5,1)), Dim2)), 1, 1)*(-999.789);    % make sure to switch FY0 after yyyy/5/1
            Temp  = iff(isnan(subset(wCons.(FY1).NIs.avg, datenum(yyyy,5,1), Dim2)), 1, 1)*(-999.789);    % make sure to switch FY0 after yyyy/5/1
%           Temp  = tshift(subset(wCons.(FY0).NIs.act, Dim1, Dim2), 1);
%           Temp  = merge(Temp, iff(isnan(subset(Temp, Dim1(Dim1==datenum(yyyy,5,1)), Dim2)), 1, 1)*(-999.789));  % make sure to switch FY0 after yyyy/5/1
            wConStop = iff(Temp==-777.789 | Temp==-888.789 | Temp==-999.789, 1, NaN);   
%           wConStop = iff(Temp==-999.789, 1, NaN);   
        else
            wConStop = iff(isnan(wCons.(FY1).NIs.avg), NaN, NaN);
        end
        wConStop = ttlast(wConStop, {-999,0}, Dim1, Dim2);                  % when wConStop==1 stops using NIs(yyyy-1)

        for i = 1:size(Vars,1)                                              % {'EPS','NIs','Rev'}
            var = Vars{i,1};   ftr=Vars{i,2};
            Temp0 = subset(wCons.(FY0).(var).(ftr), Dim1, Dim2);
            Temp1 = subset(wCons.(FY1).(var).(ftr), Dim1, Dim2);
            Temp2 = subset(wCons.(FY2).(var).(ftr), Dim1, Dim2);
            Temp3 = subset(wCons.(FY3).(var).(ftr), Dim1, Dim2);            % Temp3 = Temp2;

            fFY0 = iff(isnan(wConStop), Temp0, Temp1);  fFY0 = merge(wConsensus.(var).(ftr).FY0, iff(isnan(fFY0),-333.456, fFY0));   % let fFY0 data win over existing wConsensus data
            fFY1 = iff(isnan(wConStop), Temp1, Temp2);  fFY1 = merge(wConsensus.(var).(ftr).FY1, iff(isnan(fFY1),-333.456, fFY1));
            fFY2 = iff(isnan(wConStop), Temp2, Temp3);  fFY2 = merge(wConsensus.(var).(ftr).FY2, iff(isnan(fFY2),-333.456, fFY2));
            fFY3 = iff(isnan(wConStop), Temp3, NaN);    fFY3 = merge(wConsensus.(var).(ftr).FY3, iff(isnan(fFY3),-333.456, fFY3));

            wConsensus.(var).(ftr).FY0 = iff(fFY0==-333.456, NaN, fFY0);
            wConsensus.(var).(ftr).FY1 = iff(fFY1==-333.456, NaN, fFY1);
            wConsensus.(var).(ftr).FY2 = iff(fFY2==-333.456, NaN, fFY2);
            wConsensus.(var).(ftr).FY3 = iff(fFY3==-333.456, NaN, fFY3);
        end % i
    end  % for yyyy
    save([dirData '\wConsensusFY0123.mat'], 'wConsensus');

end     