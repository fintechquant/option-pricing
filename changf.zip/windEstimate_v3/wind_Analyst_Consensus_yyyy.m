function wind_Analyst_Consensus_yyyy(yyyy)                                  % 2004:2020

    dirRoot = getDir('Production');      dirData = [dirRoot '\Data\data2github'];      % 'Production'  'D:\PinFu-WS-01\Production'

    mpower = (0.5)^(1/45);                                                  % ��˥��=90
    load([dirData '\BroksMap.mat']);
    load([dirData '\windAnalystTable.mat']);                                 % tbl0A
    idx = find(windAnalystTable.F4_1571==yyyy*10000+1231);
    windAnalystTable = windAnalystTable(idx,:);
    windAnalystTable(datenum(num2str(cell2mat(windAnalystTable.upDate)),'yyyymmdd')-datenum(num2str(windAnalystTable.F5_1571),'yyyymmdd')>14,:) = [];
    Brokers  = unique(windAnalystTable.BrokerMap);
    year1231 =        windAnalystTable.F4_1571;   
    broker   =        windAnalystTable.BrokerMap;
    firstime =        windAnalystTable.firstime;
    lasttime =        windAnalystTable.lasttime;

    Year = num2str(yyyy);
    Dim1 = [datenum(yyyy-2,1,1) : min([today() datenum(yyyy+1,5,1)])]';
    Dim2 = {};
    Temp = compact(TdT(' ', 'merge', {20151111,'S',NaN}, 'mattbl','tbl',  'type', {'date','cell','double'}));
    wConsWV.EPS = Temp;  wConsWt.EPS = Temp;  wConsNo.EPS = Temp; 
    wConsWV.NIs = Temp;  wConsWt.NIs = Temp;  wConsNo.NIs = Temp; 
    wConsWV.Rev = Temp;  wConsWt.Rev = Temp;  wConsNo.Rev = Temp; 
    tic;
    for brk = Brokers'
%       idx   = find(broker==brk);  
        idx   = find(broker==brk & (isnan(lasttime)|lasttime>60)); 
%       idx   = find(year1231==yyyy*10000+1231 & broker==brk);  
%       idx   = find(year1231==yyyy*10000+1231 & broker==brk & (isnan(lasttime)|lasttime>60));
        yrbrk = [Year '1231 ' BroksMap{brk,2}];         display([num2str(brk) ' ' yrbrk '  ' num2str(numel(idx)) ' ' num2str(toc)]);
        if  numel(idx)>0
            wind.EPS1 = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17  7])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.EPS2 = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17  8])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.EPS3 = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17  9])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.NI1  = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17 10])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.NI2  = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17 11])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.Rev  = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17 12])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.SHRs = TdT(yrbrk, 'merge', table2cell(windAnalystTable(idx,[16 17 14])), 'mattbl','tbl',  'type', {'date','cell','double'}, 'datefmt','yyyymmdd');
            wind.EPS  = iff(~isnan(wind.EPS1), wind.EPS1, wind.EPS2);
            wind.EPS  = iff(~isnan(wind.EPS),  wind.EPS,  wind.EPS3);
%           wind.NIs  = iff(~isnan(wind.NI1),  wind.NI1,  wind.NI2);
            wind.NIs  = iff(~isnan(wind.NI2),  wind.NI2,  wind.NI1);
            wind.NIs  = iff(~isnan(wind.NIs),  wind.NIs,  wind.EPS*wind.SHRs);
            wind.EPS  = iff(~isnan(wind.EPS),  wind.EPS,  wind.NIs/wind.SHRs);
%           Dim1      = unique([Dim1; wind.EPS.Dim1]);   Dim1 = Dim1(Dim1>=datenum(yyyy-2,1,1) & Dim1<datenum(yyyy+1,5,1) & Dim1<=today());
            Dim2      = unique([Dim2, wind.EPS.Dim2, wind.NIs.Dim2]);
            for var = {'NIs'}
                var = var{:};
                DayPassed     = repDim1(subset(wind.(var), Dim1, Dim2));
                Temp          = subset(wind.(var),  Dim1, Dim2);
                DayPassed     = DayPassed - ttlast(iff(~isnan(DayPassed*Temp), DayPassed, NaN), {-9999,0});  % ����һ��Ԥ�����ھ��뵱��ʱ��  {-180,0} {-999,0}
                DayPassed     = modify(DayPassed, 'Data', power(mpower, DayPassed.Data));                    % ��˥�� = mpower
                DayPassed     = iff(isnan(DayPassed), 0, DayPassed);
                Temp1         = subset(wConsWt.(var), Dim1, Dim2);
                wConsWt.(var) = iff(isnan(Temp1), 0, Temp1) + DayPassed;
                Temp1         = subset(wConsWV.(var), Dim1, Dim2);
                Temp2         = ttlast(wind.(var), {-9999,0}, Dim1, Dim2);                                   % {-180,0} {-999,0}
                wConsWV.(var) = iff(isnan(Temp1), 0, Temp1) + DayPassed*iff(isnan(Temp2), 0, Temp2);
                Temp1         = subset(wConsNo.(var), Dim1, Dim2);
                wConsNo.(var) = iff(isnan(Temp1), 0, Temp1) + iff(isnan(DayPassed*Temp2), 0, 1);
            end
        end
    end % brk


    status = 0;
    while status(1) == 0
        pause(1);   status = dlmread([dirData '\wConsensusFY' Year '_status.txt']);    % status=0 not ready to read else ready to read & write 
    end
    dlmwrite([dirData '\wConsensusFY' Year '_status.txt'], [0 status(2) 0 status(4)]); % lock the file  
    load([dirData '\wConsensusFY' Year '.mat']);
    
    for var = {'NIs'}
        var = var{:};      
        switch var
            case 'EPS'
                 wConsensus.EPS.avg = iff(wConsNo.EPS>0, wConsWV.EPS/wConsWt.EPS, NaN);
                 wConsensus.EPS.num =     wConsNo.EPS;  
            case 'NIs'
                 wConsensus.NIs.avg = iff(wConsNo.NIs>0, wConsWV.NIs/wConsWt.NIs, NaN);
                 wConsensus.NIs.num =     wConsNo.NIs;  
            case 'Rev'
                 wConsensus.Rev.avg = iff(wConsNo.Rev>0, wConsWV.Rev/wConsWt.Rev, NaN);
                 wConsensus.Rev.num =     wConsNo.Rev;  
            otherwise
                 disp([var ' is not valid']);
        end
    end  % for var
    save([dirData '\wConsensusFY' Year '.mat'], 'wConsensus');               % display([dirData 'wConsensusFY' Year '.mat Consensus saved']);
    dlmwrite([dirData '\wConsensusFY' Year '_status.txt'], [1 status(2) 1 status(4)]);   % unlock the file
    
end  % 