%key=1 sql server data; key=2 datacsv; 
function windAnalyst_Data(date1, date2, key)
%   windAnalyst_Data(datestr(today()-4,'yyyymmdd'), datestr(today(),'yyyymmdd'));

    tic

    if nargin == 2
        key = 1; %Ĭ�ϴ�sql��ȡ����windAnalyst����
    end

    if  isnumeric(date1)
        date1 = num2str(date1);    date2 = num2str(date2);
    end
    dates = today()-13999:today()+20;
    dates = dates(dates>=datenum(date1,'yyyymmdd') & dates<=datenum(date2,'yyyymmdd'));

    dirRoot = getDir('Production');     dirData = [dirRoot '\Data\data2github'];          % 'Production'  'D:\PinFu-WS-01\Production'
    
    load([dirData '\windAnalystTable.mat']);      
    if  key == 1 %datasource: matlab Tab
        load([dirData '\wdbTable1571']);    
    elseif key == 2 %datasource: new version csv
        wdbTable1571 = [];
        for t = dates
            date0 = datestr(t,'yyyymmdd');
            fname = [dirRoot '\DataCsv_production\1571_' num2str(date0) '.csv'];
            if exist(fname, 'file')>0            % clear tableCsv;
               try
                  tableCsv = readBrokers1571Csv(fname);
                  wdbTable1571 = [wdbTable1571;tableCsv];
                  if mod(t,5)==0
                    pause(5);
                    system('taskkill /F /IM EXCEL.EXE');
                    pause(5);
                  end
               catch
                  disp(['read ' fname ' 0 rows  ' num2str(toc,'%9.2f') ' sec with errors' ]);
               end
            end
        end   % for t
        wdbTable1571 = unique(wdbTable1571);
    end
    
    load([dirData '\BroksMap.mat']);
    
    %add new rows        
    maxDate0 = max(cell2mat(windAnalystTable.upDate));
    maxID    = max(windAnalystTable.UniqueID);
    tableTab = readBrokers1571Tab(wdbTable1571,date1,BroksMap,1,maxID);
    
    if isempty(tableTab)
        
        disp('û����Ҫ���µ�����,��������date1--date2������������ݿ����');
        
    else
        maxDate0num = datenum(num2str(maxDate0),'yyyymmdd');
        table0 = table2array(windAnalystTable(:,[3:12 15]));    table0(isnan(table0)) = -888.888;
        table1 = table2array(tableTab(:,        [3:12 15]));    table1(isnan(table1)|table1==-999.888) = -888.888;
        table0(:,8) = floor(table0(:,8)); table0(:,9) = floor(table0(:,9)); table0(:,10) = floor(table0(:,10)); %������Ƚϴ�������С�������ٱȽ�
        table1(:,8) = floor(table1(:,8)); table1(:,9) = floor(table1(:,9)); table1(:,10) = floor(table1(:,10));
        idx    = ismember(table1, table0, 'rows');
        idx2   = (datenum(num2str(table1(:,2)),'yyyymmdd') - maxDate0num >= -10);
        disp(['read ' num2str(size(tableTab((~idx)&idx2,:),1)) ' rows  ' num2str(toc,'%9.2f') ' sec' ]);

        if size(tableTab((~idx)&idx2,:),1) == 0

            disp('û����Ҫ�������ӵ�����');

        else
            tic
            windAnalystTable = [windAnalystTable; tableTab((~idx)&idx2,:)];
            windAnalystTable = sortrows(windAnalystTable, {'upDateStr','F16_1090','F2_1571','F29_1571','F4_1571'});

            windAnalystTable(cell2mat(windAnalystTable.upDate)==cell2mat(windAnalystTable.deleteDate),:) = [];
            table0 = table2array(windAnalystTable(:,[3 6 7 10 11 15]));    table0(isnan(table0)) = -888.888;

            windTable4C = table0;
            windTable4C(:,7) = windAnalystTable.firstime;
            windTable4C(:,8) = windAnalystTable.lasttime;
            windTable4C(:,9) = windAnalystTable.UniqueID;
            windTable4C(:,10) = datenum(windAnalystTable.upDateStr,'yyyy-mm-dd HH:MM:SS.0');
            windTable4mat = for_matlab_wEstfun0(windTable4C);


            if isempty(find(windAnalystTable.UniqueID - windTable4mat(:,9)~=0))
                idx3 = find(isnan(windAnalystTable.firstime)&isnan(windAnalystTable.lasttime));
                windAnalystTable(idx3,18) = num2cell(windTable4mat(idx3,7));
                windAnalystTable(idx3,19) = num2cell(windTable4mat(idx3,8));
            else
                error('˳��Բ��ϣ�');
            end
            save([dirData '\windAnalystTable.mat'], 'windAnalystTable'); 

        end

        toc
        
    end

end

% function tableCsv = readBrokers1571Csv(date0, fname, BroksNoMap)
%    try
%         [a,~,c] = xlsread(fname);
%       % x = readtable(fname, 'Delimiter',',','Format','%f %s %f %f %f %f %f %f %f %f %f %f');
%         c{1,1} = 'No';
%         cell2table()
%       
%         c{1,1} = 'No';       c(2:end,3:12) = num2cell(a(:,3:12));
%         tableCsv = cell2table(c(2:end,:),'VariableNames',c(1,:));
%         try
%            BrokerMap = cell2mat(values(BroksNoMap, tableCsv.F2_1571));
%            idx       = isnan(BrokerMap);
%            if sum(idx)>0
%               display([unique(tableCsv.F2_1571(idx)) ' is not in the BroksNoMap']);
%               % email
%               tableCsv  = tableCsv(~idx,:);
%               BrokerMap = BrokerMap(~idx);
%            end
% %          BrokerMap = cell2mat(values(BroksNoMap, tableCsv.F2_1569));
%         catch
%            display([fname ' is neither 1571 nor 1569']);
%         end
%         
%         if strcmp(date0,'20171206')==1
%            upDate = tableCsv.F29_1571;
%            upDate(isnan(upDate)) = tableCsv.F5_1571(isnan(upDate));
%            upDate = datenum(num2str(upDate),'yyyymmdd') + 1;
%            upDate = year(upDate)*10000+month(upDate)*100+day(upDate);
%         else
%            upDate = ones(numel(BrokerMap),1)*str2num(date0);
%         end
%         
%         F16_1090   = tableCsv.F16_1090; 
%         a   = num2cell(F16_1090); b = cellfun(@(x) ['000000' num2str(x)],a,'UniformOutput',false); c = cellfun(@(x) x(end-5:end),b,'UniformOutput',false);
%         idx = F16_1090 - 600000 > 0; c(idx) = cellfun(@(x) [x '.SH'], c(idx), 'UniformOutput', false); c(~idx) = cellfun(@(x) [x '.SZ'], c(~idx), 'UniformOutput', false);
%         ID  = c;
%        
% %       when shares is missing, F30_1571,F31_1571 did not add more obs than  F6_1571 
%         shares = tableCsv.F34_1571./tableCsv.F6_1571;
%         idx    = find(isnan(shares));
%         shares(idx) = tableCsv.F8_1571(idx)./tableCsv.F6_1571(idx);
%         
%         F23_1571 = NaN(numel(shares),1);
%         firstime = NaN(numel(BrokerMap),1);
%         lasttime = NaN(numel(BrokerMap),1);
%         
%         if ~isempty(find(strcmp(tableCsv.Properties.VariableNames,'OB_OBJECT_ID')))
%             OB_OBJECT_ID = tableCsv.OB_OBJECT_ID;
%             tableCsv.OB_OBJECT_ID = [];
%         else
%             OB_OBJECT_ID  = repmat({'A0'},[numel(BrokerMap) 1]);
%         end
%         
%         deleteDate    = NaN(numel(BrokerMap),1);
%         upDateStr     = datestr(datenum(num2str(upDate),'yyyymmdd')+9.25/24,'yyyy-mm-dd HH:MM:SS.0');
%         deleteDateStr = repmat({''}  ,[numel(BrokerMap) 1]);
%         
%         tableCsv.No = [];
%         tableCsv = [table(OB_OBJECT_ID) tableCsv table(F23_1571, shares, BrokerMap, upDate, ID, firstime, lasttime,  deleteDate, upDateStr, deleteDateStr)];
%    catch
%         display([fname ' cannot be found or reading error']);
%    end
% end

% function tableSql = readBrokers1571Sql(BroksNoMap)
%    i = 0;
%    for brk = BroksNoMap.keys
%        i = i+1;
%        Broker = brk{:};   % '����֤ȯ'  brk{:}
%        sql1571 = [' SELECT 0 as No, F2_1571, CONVERT(INT,F16_1090) AS F16_1090, CONVERT(INT,F29_1571) AS F29_1571, CONVERT(INT,F5_1571) AS F5_1571, '    char(10) ...
%                   '                          CONVERT(INT,F4_1571)  AS F4_1571, F6_1571, F30_1571, F31_1571, F8_1571, F34_1571, F7_1571, F23_1571 '       char(10) ...
%                   ' FROM TB_OBJECT_1571, TB_OBJECT_1090 '                                                                                                char(10) ...
%                   ' WHERE TB_OBJECT_1571.F1_1571=TB_OBJECT_1090.OB_REVISIONS_1090 and F4_1090=''A'' and F16_1090<''A00000'' and F2_1571=''' Broker ''''  char(10) ...  
%                   ' ORDER by F16_1090, F29_1571, F4_1571'];
%        if mod(i,10)==1
%           display(sql1571);
%        end
%        try
%           data1571 = DataBaseFetcher.getDataFromWind(sql1571, true);
%           xx = cell2mat(data1571(2:end,4:end));
%           xx(xx==0)=NaN;
%           data1571(2:end,4:end) = num2cell(xx);              % cellfun(@str2num,regexprep(data1571,'\D',''))
%           table1 = cell2table(data1571(2:end,:),'VariableNames',data1571(1,:));
%           if  exist('tableSql','var')
%               tableSql = [tableSql; table1];
%           else
%               tableSql = table1;
%           end
%           display([num2str(i) ' ' Broker ' has ' num2str(size(data1571,1)) ' rows']);
%        catch
%           display([num2str(i) ' ' Broker ' has 0 rows']);
%        end
%    end
%    
%    BrokerMap = cell2mat(values(BroksNoMap, tableSql.F2_1571));
%    idx       = isnan(BrokerMap);
%    if sum(idx)>0
%       display([unique(tableSql.F2_1571(idx)) ' is not in the BroksNoMap']);
%       % email
%       tableSql  = tableSql(~idx,:);
%       BrokerMap = BrokerMap(~idx);
%    end
%    
%    firstime = NaN(numel(BrokerMap),1);
%    lasttime = NaN(numel(BrokerMap),1);
%    
%    upDate = tableSql.F29_1571;
%    upDate(isnan(upDate)) = tableSql.F5_1571(isnan(upDate));
% %  upDate = table2array(upDate);
%    upDate = datenum(num2str(upDate),'yyyymmdd') + 1;
%    upDate = year(upDate)*10000+month(upDate)*100+day(upDate);
%    
%    Id = table2array(tableSql(:,3));     ID = table2array(tableSql(:,2));
%    for i = 1:numel(Id)
%        id = ['0000000' num2str(Id(i))];
%        if Id(i)>=600000
%           ID(i) = {[id(end-5:end) '.SH']};
%        else 
%           ID(i) = {[id(end-5:end) '.SZ']};
%        end
%    end
%    
%    % when shares is missing, F30_1571,F31_1571 did not add more obs than  F6_1571 
%    shares = tableSql.F23_1571; 
%    idx = find(isnan(shares) & ~isnan(tableSql.F6_1571)  & ~isnan(tableSql.F34_1571));
%    shares(idx) = tableSql.F34_1571(idx)./tableSql.F6_1571(idx);
%    idx = find(isnan(shares));
%    shares(idx) = tableSql.F8_1571(idx)./tableSql.F6_1571(idx);
%    
%    tableSql = [tableSql table(shares, BrokerMap, upDate, ID, firstime, lasttime)];
%    tableSql = sortrows(tableSql, {'upDate','F16_1090','F2_1571','F29_1571','F4_1571'});
% end

function tableCsv = readBrokers1571Csv(fname)
   try
        [a,~,c] = xlsread(fname);
        c{1,1} = 'No';
        
        if size(c,1) == 1
            
            c{1,1}  = 'F16_1090';
            c{1,51} = 'sqlRunTime';
            c{1,52} = 'sqlDeleteTime';
            tableCsv = cell2table(c(2:end,1:end),'VariableNames',c(1,1:end));
            
        else
        
            %��������'NA'---->-999.888
            numcol = [10:12,19:27,30,32,34:43,45:50];
            d = c(2:end,numcol);
            d(strcmp(d,'NA')) = {-999.888};
            c(2:end,numcol) = d;

            %��������F1_1571��double---->string
            temp   = c(2:end,5);
            for i = 1:length(temp)
                if ~ischar(temp{i})
                    temp{i} = num2str(temp{i});
                end
            end
            c(2:end,5) = temp;

            %����F16_1090��double---->string
            a1  = c(2:end,2); a2 = cellfun(@(x) ['000000' num2str(x)],a1,'UniformOutput',false); a3 = cellfun(@(x) x(end-5:end),a2,'UniformOutput',false);
            c(2:end,2)  = a3;

            %����RP_GEN_DATETIM & OB_RELEASE_TIME ----> MATLAB TIME
            temp = datestr(cell2mat(c(2:end,15)) + 693960, 'yyyy-mm-dd HH:MM:SS.0');  c(2:end,15) = cellstr(temp);
            temp = datestr(cell2mat(c(2:end,44)) + 693960, 'yyyy-mm-dd HH:MM:SS.0');  c(2:end,44) = cellstr(temp);

            %����F25_1571�е�ÿ��'���ʲ�����'
            c(2:end,32) = {-999.88};

            tableCsv = cell2table(c(2:end,2:end),'VariableNames',c(1,2:end));

            tableCsv.sqlRunTime = tableCsv.RP_GEN_DATETIME;
            tableCsv.sqlDeleteTime = tableCsv.sqlRunTime; tableCsv.sqlDeleteTime = repmat({''},[height(tableCsv),1]);
            
        end
   catch
        disp([fname ' cannot be found or reading error']);
   end
end

function tableTab = readBrokers1571Tab(wdbTable1571,date0,BroksMap,key,maxID)
  
    if isempty(wdbTable1571) %��csv��ȡ�����ܳ���������
        
        tableTab = table();
        
    else

        select_col = {'OB_OBJECT_ID','F2_1571','F16_1090','F29_1571','F5_1571','F4_1571','F6_1571','F30_1571','F31_1571','F8_1571','F34_1571','F7_1571','F23_1571','sqlRunTime','sqlDeleteTime'}; 
        if  key == 1 %add rows
            table1  = wdbTable1571(datenum(wdbTable1571.sqlRunTime,'yyyy-mm-dd HH:MM:SS') >= datenum(date0,'yyyymmdd'),select_col); 
        elseif key == 2 %delete rows
            table1  = wdbTable1571(datenum(wdbTable1571.sqlDeleteTime,'yyyy-mm-dd HH:MM:SS') >= datenum(date0,'yyyymmdd') & ~strcmp(wdbTable1571.sqlDeleteTime,''),select_col); 
        end

        if isempty(table1) %ѡ������������ݿⶼû�и��¿��ܳ���������

            tableTab = table();

        else

            for i = 1:size(table1,2)
                temp = table2array(table1(:,i)) ;
                if isnumeric(temp(1))
                    temp(temp==-999.888) = NaN;
                    table1(:,i)          = num2cell(temp);
                end
            end

            shares     = table1.F34_1571./table1.F6_1571; 
            
            secnames = table1.F2_1571;
            secnames(strcmp(secnames,'����֤ȯ')) = {'��Ѷ֤ȯ'};
            table1.F2_1571 = secnames;

            BroksNoMap = containers.Map(BroksMap(:,2),BroksMap(:,1));
            id = unique(table1.F2_1571);
            for i = 1:length(id)
                try
                    values(BroksNoMap, id(i));
                catch
                    l = max(cell2mat(BroksMap(:,1)));
                    BroksMap{l+1,1} = l+1;
                    BroksMap{l+1,2} = cell2mat(id(i));
                    disp(['update new broker' cell2mat(id(i))]);
                end
            end
            dirRoot = getDir('Production');     dirData = [dirRoot '\Data\'];
            save([dirData 'BroksMap.mat'],'BroksMap','-v7.3');
            BroksNoMap = containers.Map(BroksMap(:,2),BroksMap(:,1));
            BrokerMap  = cell2mat(values(BroksNoMap, table1.F2_1571));

            F16_1090   = str2num(cell2mat(table1.F16_1090)); 
            a   = num2cell(F16_1090); b = cellfun(@(x) ['000000' num2str(x)],a,'UniformOutput',false); c = cellfun(@(x) x(end-5:end),b,'UniformOutput',false);
            idx = F16_1090 - 600000 > 0; c(idx) = cellfun(@(x) [x '.SH'], c(idx), 'UniformOutput', false); c(~idx) = cellfun(@(x) [x '.SZ'], c(~idx), 'UniformOutput', false);
            ID  = c;

            firstime   = NaN(numel(BrokerMap),1);
            lasttime   = NaN(numel(BrokerMap),1);

            tradingdate = datenum(table2array(table1(:,14)),'yyyy-mm-dd HH:MM:SS.0'); idx_plus1 = (tradingdate>=floor(tradingdate) + 8.75/24); 
            tradingdate = floor(tradingdate);  tradingdate(idx_plus1) = tradingdate(idx_plus1) + 1;
            upDate   = num2cell(str2num(datestr(tradingdate,'yyyymmdd'))); 

            idx_null = strcmp(table2array(table1(:,15)),''); table1(idx_null,15) = {'1900-01-01 00:00:00.0'};
            tradingdate = datenum(table2array(table1(:,15)),'yyyy-mm-dd HH:MM:SS.0'); idx_plus1 = (tradingdate>=floor(tradingdate) + 8.75/24); 
            tradingdate = floor(tradingdate);  tradingdate(idx_plus1) = tradingdate(idx_plus1) + 1;
            deleteDate  = num2cell(str2num(datestr(tradingdate,'yyyymmdd')));
            deleteDate(idx_null) = {NaN}; 
            table1.sqlDeleteTime(idx_null) = {''};

            upDateStr = table1.sqlRunTime;
            deleteDateStr = table1.sqlDeleteTime;
            table1.sqlRunTime = []; table1.sqlDeleteTime = [];
            tableTab            = [table1 table(shares, BrokerMap, upDate, ID, firstime, lasttime, deleteDate, upDateStr, deleteDateStr)];
            tableTab.F16_1090   = F16_1090;
            tableTab.UniqueID   = ((maxID+1):(maxID+size(tableTab,1)))';

            tableTab(cell2mat(tableTab.upDate)==cell2mat(tableTab.deleteDate),:) = [];

        end
        
    end
    
end
