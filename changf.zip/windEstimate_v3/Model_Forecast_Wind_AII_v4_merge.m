function Model_Forecast_Wind_AII_v4_merge
%��ʱ��������ƽ���ĳ��γ���
% one factor quickly test

    BeginDate   = '20121231';                                                     %  '20171123'
    HedgeIdx    = {'000905.SH'};   
    
%% LoadData

    dirRoot = getDir('Production');       dirData = [dirRoot '\Data']            % 'Production'  'D:\PinFu-WS-01\Production'
    dirTrading = [dirData '\Trading']
    
    load([dirData '\wPrc_Stocks.mat']);
    load([dirData '\wPrc_Indices.mat']);
    load([dirData '\wPrc_Events.mat']);
    load([dirData '\wConsensusFY0123.mat']);
    load([dirData '\CDSys_Var1.mat']);

    load([dirData '\factors_zyd\normalizeAll_winsorize_AdT2_Size_Size.mat']);
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Value1_DE2P.mat']);
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Value2_RE2P.mat']);
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Momentum1_SUE.mat']);
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Sentiment_VOL.mat']);
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Sentiment_FFRsqrA1.mat']);
    orthogonalize_normalizeAll_winsorize_FactorLab.Size.Size          = Size;
    orthogonalize_normalizeAll_winsorize_FactorLab.Value1.DE2P        = DE2P;
    orthogonalize_normalizeAll_winsorize_FactorLab.Value2.RE2P        = RE2P;
    orthogonalize_normalizeAll_winsorize_FactorLab.Momentum1.SUE      = SUE;
    orthogonalize_normalizeAll_winsorize_FactorLab.Sentiment.VOL      = VOL;
    orthogonalize_normalizeAll_winsorize_FactorLab.Sentiment.FFRsqrA1 = FFRsqrA1;
    clear Size DE2P RE2P SUE VOL FFRsqrA1;


%% prepare DF

    clear DF;
    DF.IntraDay0 = CDSys_Var.Type_Price_Name_Twap0930_FormTime_0930_0930;
    DF.IntraDay1 = CDSys_Var.Type_Price_Name_Twap1000_FormTime_0930_1000;      % 'Open' 'Open';  'AVClose'
    DF.IntraDay2 = CDSys_Var.Type_Price_Name_Twap1430_FormTime_1400_1430;
    Dim1         = wPrc_Stocks.Close.Dim1;
    Dim1         = Dim1(Dim1>=datenum(BeginDate,'yyyymmdd'));  
    Dim2         = unique([wPrc_Stocks.Close.Dim2,  wPrc_Indices.Close.Dim2]);
    
    DF.IntraDay0 = subset(DF.IntraDay0,          Dim1,Dim2);
    DF.IntraDay1 = subset(DF.IntraDay1,          Dim1,Dim2);
    DF.IntraDay2 = subset(DF.IntraDay2,          Dim1,Dim2);
    DF.Open      = subset(merge(wPrc_Stocks.Open,      wPrc_Indices.Open),      Dim1,Dim2); 
    DF.Close     = subset(merge(wPrc_Stocks.Close,     wPrc_Indices.Close),     Dim1,Dim2); 
    DF.Pre_Close = subset(merge(wPrc_Stocks.Pre_Close, wPrc_Indices.Pre_Close), Dim1,Dim2); 
    DF.AdjFactor = subset(wPrc_Stocks.AdjFactor, Dim1,Dim2); 
    DF.Volume    = subset(wPrc_Stocks.Volume,    Dim1,Dim2); 
    DF.Amt       = subset(wPrc_Stocks.Amt,       Dim1,Dim2); 
    DF.AmtRank   = xrank(-ttmean(DF.Amt,{-60,0}, Dim1,Dim2));
    DF.AmtMean    = trmean(DF.Amt, {-9,0}, Dim1, Dim2);
    
    DF.iftrade0  = iff(tshift(DF.Amt,1)>0, 1, NaN);                                                                   % ������Ҫ����
    tempdata = DF.iftrade0.Data; tempdata(end,:) = tempdata(end-1,:); DF.iftrade0.Data = tempdata;
    DF.iftrade1  = tshift(DF.Open/DF.Pre_Close-1,1);                                                                  % ���տ����Ƿ�
    DF.iftrade1  = iff(DF.iftrade1>-0.08 & DF.iftrade1<0.08, 1, NaN);                                                 % ���տ��̷��ǵ�ͣ
    tempdata = DF.iftrade1.Data; tempdata(end,:) = ones(1,length(tempdata(end,:))); DF.iftrade1.Data = tempdata;
 %  DF.iftrade1  = DF.iftrade1 * iff(tshift(DF.IntraDay0/DF.Open-1,1)>-0.28 & tshift(DF.IntraDay0/DF.Open-1,1)<0.21, 1, NaN);    % ���տ���->9;30
    DF.notST     = ttlast(merge(wPrc_Events.CarryoutSpecialTreatment,iff(wPrc_Events.CancelSpecialTreatment==1,0,NaN)), {-inf,0}, Dim1, Dim2);
    DF.notST     = iff(DF.notST==1, NaN, 1);
    DF.Size       = xrankII(-log(subset(wPrc_Stocks.Float_A_Shares, Dim1, Dim2) * subset(wPrc_Stocks.Close, Dim1, Dim2)));
    
    Ret.r1 = DF.Close/DF.Pre_Close;   Ret.r1 = Ret.r1 - subset(Ret.r1, Dim1, HedgeIdx);     % Excess return
    Ret.r2 = DF.Close/DF.IntraDay1;   Ret.r2 = Ret.r2 - subset(Ret.r2, Dim1, HedgeIdx);     % Excess return  Open  IntraDay1
    Ret.r3 = DF.Close/DF.IntraDay2;   Ret.r3 = Ret.r3 - subset(Ret.r3, Dim1, HedgeIdx);     % Excess return  Close IntraDay2

    
%% Factor Create
%  i=1; x= [wConsensus.NIs.f1.FY0.Data(:,i) wConsensus.NIs.f1.FY1.Data(:,i) wConsensus.NIs.f1.FY2.Data(:,i) wConsensus.NIs.f1.FY3.Data(:,i)];
    tic
    disp('����m1......');
    factor     = iff(isnan(wConsensus.NIs.f1.FY2),0,wConsensus.NIs.f1.FY2)*1.3 + ...
                 iff(isnan(wConsensus.NIs.f1.FY3),0,wConsensus.NIs.f1.FY3)*1.2 + ...
                 iff(isnan(wConsensus.NIs.f1.FY1),0,wConsensus.NIs.f1.FY1)*1.1 + ...
                 iff(isnan(wConsensus.NIs.f1.FY0),0,wConsensus.NIs.f1.FY0)*1.0 ;   

    factor = iff(isnan(wConsensus.NIs.f1.FY2)&isnan(wConsensus.NIs.f1.FY3)&...
                 isnan(wConsensus.NIs.f1.FY1)&isnan(wConsensus.NIs.f1.FY0), NaN, factor);      
  
    factor  = ttlast(factor,{Dim1+1,[Dim1(2:end);9999999]},Dim1,Dim2)*DF.notST;
    factor     = iff(factor>0, factor, NaN);
    factorscore = factor * DF.iftrade0 * DF.iftrade1;
    factor     = xrank(factor)/xmax(xrank(factor));
    Factor.f0  = iff(isnan(factor), 0, factor);    %show(xcount(iff(Factor.f0==0,NaN,Factor.f0)));

    factor     = merge(wConsensus.NIs.f2.FY2, wConsensus.NIs.f2.FY1);
    factor     = ttlast(factor,{Dim1+1,[Dim1(2:end);9999999]},Dim1,Dim2);
    temp       = iff(abs(factor-1)<0.00001,1,NaN);
    factor     = xrank(factor)/xmax(xrank(factor));
    Factor.f1  = iff(isnan(factor)|temp==1, xmean(temp*factor), factor); %2019-5-7��,��Facotr.f1��NaN�Ĺ�ƱҲ��Ӱ���������ӵĴ��

    factor     = subset(orthogonalize_normalizeAll_winsorize_FactorLab.Value1.DE2P,       Dim1,Dim2);
    Factor.f2  = xrank(factor)/xmax(xrank(factor)); 
    factor     = subset(orthogonalize_normalizeAll_winsorize_FactorLab.Value2.RE2P,       Dim1,Dim2);
    Factor.f3  = xrank(factor)/xmax(xrank(factor));
    factor     = subset(orthogonalize_normalizeAll_winsorize_FactorLab.Momentum1.SUE,     Dim1,Dim2);
    Factor.f4  = xrank(factor)/xmax(xrank(factor));
    factor     = subset(orthogonalize_normalizeAll_winsorize_FactorLab.Sentiment.VOL,     Dim1,Dim2);
    Factor.f5  = xrank(factor)/xmax(xrank(factor)); 
    factor     = subset(orthogonalize_normalizeAll_winsorize_FactorLab.Sentiment.FFRsqrA1,Dim1,Dim2);
    Factor.f6  = xrank(factor)/xmax(xrank(factor)); 
    factor     = subset(orthogonalize_normalizeAll_winsorize_FactorLab.Size.Size,         Dim1,Dim2);
    Factor.f7  = xrank(factor)/xmax(xrank(factor)); 
    
    load([dirData '\factors_lqy\seasonality2.mat']);
    factor = subset(a, Dim1, Dim2);
    factor = xrankII(-factor,20);
    factor = iff(factor>=10,10,factor)/10;
    factor = iff(isnan(factor), 0, factor);
    Factor.f8 = factor;

    AlphaScore = 1.00*Factor.f0 + 0.50*Factor.f1 + 0.25*Factor.f2 + 0.25*Factor.f3 + 0.25*Factor.f4 + 0.25*Factor.f5 + 0.25*Factor.f6 + 0.25*Factor.f7 + 0.2*Factor.f8;
    AlphaScore = AlphaScore * iff(Factor.f0>0, 0.9, 1);

%   ##################
    AlphaScore2 = AlphaScore * iff((DF.AmtRank>100 & DF.AmtRank<2500 & DF.Pre_Close>5), NaN, 1);  
    AlphaScore  = AlphaScore * iff((DF.AmtRank>100 & DF.AmtRank<2500 & DF.Pre_Close>5), 1, NaN);
    AlphaRank   = xrank(-AlphaScore);
    AlphaScore  = iff(trmin(AlphaRank,{-4,0})<=50&trcount(AlphaRank,{-4 0})>=5&~isnan(AlphaScore2),AlphaScore2,AlphaScore);
    AlphaScore  = AlphaScore * DF.notST;
    AlphaRank   = xrank(-AlphaScore);
    
    m1 = AlphaRank;
    
    save([dirData '\m1.mat'],'m1');
    
    AlphaRank2 = transpose(AlphaRank); 
    AlphaRank2 = modify(AlphaRank2, 'Type',{'cell','numeric','double'}, 'Dim2',str2num(datestr(AlphaRank2.Dim2,'yyyymmdd'))');          %matlab����ת����excel����

    system('taskkill /F /IM EXCEL.EXE');
    TdT2Excel(compact(subset(AlphaRank2, AlphaRank2.Dim1, AlphaRank2.Dim2(end-9:end))), 'Save',[dirTrading '\500alpha_tradefile\m1_Trade' datestr(today(),'yyyymmdd') '.xlsx']);
    system('taskkill /F /IM EXCEL.EXE');
    
    clear a AlphaRank AlphaRank2 AlphaScore AlphaScore2 factor Factor factorscore m1 orthogonalize_normalizeAll_winsorize_FactorLab temp tempdata
    toc
    
    %% m2
    tic
    disp('����m2......');
    
    factor     = iff(isnan(wConsensus.NIs.f1.FY2),0,wConsensus.NIs.f1.FY2)*1.3 + ...
                 iff(isnan(wConsensus.NIs.f1.FY3),0,wConsensus.NIs.f1.FY3)*1.2 + ...
                 iff(isnan(wConsensus.NIs.f1.FY1),0,wConsensus.NIs.f1.FY1)*1.1 + ...
                 iff(isnan(wConsensus.NIs.f1.FY0),0,wConsensus.NIs.f1.FY0)*1.0 ;   

    factor = iff(isnan(wConsensus.NIs.f1.FY2)&isnan(wConsensus.NIs.f1.FY3)&...
                 isnan(wConsensus.NIs.f1.FY1)&isnan(wConsensus.NIs.f1.FY0), NaN, factor);      
  
    factor  = ttlast(factor,{Dim1+1,[Dim1(2:end);9999999]},Dim1,Dim2)*DF.notST;
    factor     = iff(factor>0, factor, NaN);
    factorscore = factor * DF.iftrade0 * DF.iftrade1;
    factor     = xrank(factor)/xmax(xrank(factor));
    Factor.f0  = iff(isnan(factor), 0, factor);    %show(xcount(iff(Factor.f0==0,NaN,Factor.f0)));
    nannum     = nansum(isnan(Factor.f0.Data(end,:)));
    disp(['f0: ' datestr(Factor.f0.Dim1(end)) ',NaN����:' num2str(nannum)])

    factor     = merge(wConsensus.NIs.f2.FY2, wConsensus.NIs.f2.FY1);
    factor     = ttlast(factor,{Dim1+1,[Dim1(2:end);9999999]},Dim1,Dim2);
    temp       = iff(abs(factor-1)<0.00001,1,NaN);
    factor     = xrank(factor)/xmax(xrank(factor));
    Factor.f1  = iff(isnan(factor)|temp==1, xmean(temp*factor), factor); %2019-5-7��,��Facotr.f1��NaN�Ĺ�ƱҲ��Ӱ���������ӵĴ��
    nannum     = nansum(isnan(Factor.f1.Data(end,:)));
    disp(['f1: ' datestr(Factor.f1.Dim1(end)) ',NaN����:' num2str(nannum)])
    
    load([dirData '\factors_lqy\SUE.mat']); 
    wEst_SUE = subset(SUE, Dim1, Dim2);
    wEst_SUE = xrankII(wEst_SUE) / xmax(xrankII(wEst_SUE));
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Momentum1_SUE.mat']);
    SUE = subset(SUE, Dim1, Dim2);
    SUE = xrankII(SUE) / xmax(xrankII(SUE));
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Momentum1_SURI.mat']); 
    SURI = subset(SURI, Dim1, Dim2);
    SURI = xrankII(SURI) / xmax(xrankII(SURI));
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Momentum1_SUOI.mat']); 
    SUOI = subset(SUOI, Dim1, Dim2);
    SUOI = xrankII(SUOI) / xmax(xrankII(SUOI));
    
    factor = 1/6 * iff(isnan(SUE),0.5,SUE) + 1/6 * iff(isnan(wEst_SUE),0.5,wEst_SUE) + 1/3 * iff(isnan(SUOI),0.5,SUOI) + 1/3 * iff(isnan(SURI),0.5,SURI);
    Factor.f2 = factor;
    
    load([dirData '\factors_lqy\RROE.mat']); 
    wEst_RROE = subset(RROE, Dim1, Dim2);
    wEst_RROE = xrankII(wEst_RROE) / xmax(xrankII(wEst_RROE));
    load([dirData '\factors_lqy\DROE.mat']); 
    wEst_DROE = subset(DROE, Dim1, Dim2);
    wEst_DROE = xrankII(wEst_DROE) / xmax(xrankII(wEst_DROE));    
    factor = 1/2 * iff(isnan(wEst_RROE),0.5,wEst_RROE) + 1/2 * iff(isnan(wEst_DROE),0.5,wEst_DROE);
    Factor.f3 = factor;   
    
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Sentiment_VOL.mat']); 
    VOL = subset(VOL, Dim1, Dim2);
    VOL = xrankII(VOL) / xmax(xrankII(VOL));    
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Sentiment_VOL5D.mat']); 
    VOL5D = subset(VOL5D, Dim1, Dim2);
    VOL5D = xrankII(VOL5D) / xmax(xrankII(VOL5D));     
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Sentiment_VOL3M.mat']);  
    VOL3M = subset(VOL3M, Dim1, Dim2);
    VOL3M = xrankII(VOL3M) / xmax(xrankII(VOL3M));     
    load([dirData '\factors_lqy\turnover3d.mat']); 
    turnover = subset(turnover3d, Dim1, Dim2);
    turnover = xrankII(turnover) / xmax(xrankII(turnover)); 
    factor = 1/4 * iff(isnan(VOL),0.5,VOL) + 1/4 * iff(isnan(VOL5D),0.5,VOL5D) + 1/4 * iff(isnan(VOL3M),0.5,VOL3M) + 1/4 * iff(isnan(turnover),0.5,turnover);
    Factor.f4 = factor;   
    
    load([dirData '\factors_lqy\RE2P.mat']);
    wEst_RE2P = subset(RE2P, Dim1, Dim2);
    wEst_RE2P = xrankII(wEst_RE2P) / xmax(xrankII(wEst_RE2P));     
    load([dirData '\factors_lqy\DE2P.mat']); 
    wEst_DE2P = subset(DE2P, Dim1, Dim2);
    wEst_DE2P = xrankII(wEst_DE2P) / xmax(xrankII(wEst_DE2P));  
    
    %DEP
    wConsensus_NI = wConsensus.NIs;
    wConsensus_NI_fy0 = ttlast(wConsensus_NI.avg.FY0,  {Dim1+1,[Dim1(2:end);9999999]},Dim1,Dim2);
    wConsensus_NI_fy1 = ttlast(wConsensus_NI.avg.FY1,  {Dim1+1,[Dim1(2:end);9999999]},Dim1,Dim2);
    weightTdT_fy0     = iff(monthTdT(wConsensus_NI_fy0)>3, (16-monthTdT(wConsensus_NI_fy0))/12, (4-monthTdT(wConsensus_NI_fy0))/12);
    weightTdT_fy1     = abs(1 - weightTdT_fy0);
    EP_FY             = weightTdT_fy0 * wConsensus_NI_fy0 + weightTdT_fy1 * wConsensus_NI_fy1 ;
    EP_FY             = subset(EP_FY, Dim1, Dim2) * 10000 / (subset(wPrc_Stocks.Total_Shares,Dim1,Dim2) * subset(iff(isnan(wPrc_Stocks.Close)==1,wPrc_Stocks.Pre_Close,wPrc_Stocks.Close),Dim1,Dim2));
    EP_FY.Name        = 'EP_FY';

    DEP_FY  = EP_FY / tshift(EP_FY,-60) - 1;      DEP_FY.Name  = 'DEP_FY_v1';
    DEP_FY2 = EP_FY / tshift(EP_FY,-40) - 1;      DEP_FY2.Name = 'DEP_FY_v2';
    DEP_FY3 = EP_FY / tshift(EP_FY,-20) - 1;      DEP_FY3.Name = 'DEP_FY_v3';

    DEP_FY_merge = xrankII(DEP_FY) / xmax(xrankII(DEP_FY)) + xrankII(DEP_FY2) / xmax(xrankII(DEP_FY2)) + xrankII(DEP_FY3) / xmax(xrankII(DEP_FY3));
    a = factor_parse(DEP_FY_merge,1);    DEP_FY_merge = a.wins_norm_sizeANDindusNeutral2;    DEP_FY_merge.Name = 'DEP_FY_merge';
    
    DEP_FY_merge = subset(DEP_FY_merge, Dim1, Dim2);
    DEP_FY_merge = xrankII(DEP_FY_merge) / xmax(xrankII(DEP_FY_merge));     
    factor = 1/4 * iff(isnan(wEst_RE2P),0.5,wEst_RE2P) + 1/4 * iff(isnan(wEst_DE2P),0.5,wEst_DE2P) + 1/2 * iff(isnan(DEP_FY_merge),0.5,DEP_FY_merge) ;
    Factor.f5 = factor;   
    nannum     = nansum(isnan(Factor.f5.Data(end,:)));
    disp(['f5: ' datestr(Factor.f5.Dim1(end)) ',NaN����:' num2str(nannum)])
    
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Quality_QDROA.mat']); 
    QDROA = subset(QDROA, Dim1, Dim2);
    QDROA = xrankII(QDROA) / xmax(xrankII(QDROA));     
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Growth_ROAG.mat']); 
    ROAG = subset(ROAG, Dim1, Dim2);
    ROAG = xrankII(ROAG) / xmax(xrankII(ROAG)); 
    factor = 1/2 * iff(isnan(QDROA),0.5,QDROA) + 1/2 * iff(isnan(ROAG),0.5,ROAG);
    Factor.f6 = factor;     
    nannum     = nansum(isnan(Factor.f6.Data(end,:)));
    disp(['f6: ' datestr(Factor.f6.Dim1(end)) ',NaN����:' num2str(nannum)])
    
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Sentiment_BETA.mat']); 
    BETA = subset(BETA, Dim1, Dim2);
    BETA = xrankII(BETA,40);
    BETA = iff(BETA>=10,10,BETA)/40; 
    BETA = iff(isnan(BETA), 10/40, BETA);
    Factor.f7 = BETA;     
    nannum     = nansum(isnan(Factor.f7.Data(end,:)));
    disp(['f7: ' datestr(Factor.f7.Dim1(end)) ',NaN����:' num2str(nannum)])
    
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Momentum2_BIAS.mat']);
    BIAS = subset(BIAS, Dim1, Dim2);
    BIAS = xrankII(BIAS) / xmax(xrankII(BIAS));
    BIAS = iff(isnan(BIAS), 0.5, BIAS);
    Factor.f8 = BIAS;
    nannum     = nansum(isnan(Factor.f8.Data(end,:)));
    disp(['f8: ' datestr(Factor.f8.Dim1(end)) ',NaN����:' num2str(nannum)])
    
    load([dirData '\factors_lqy\Seasonality.mat']); 
    factor = subset(seasonality, Dim1, Dim2);
    factor = xrankII(-factor,20);
    factor = iff(factor>=10,10,factor)/10;
    factor = iff(isnan(factor), 0, factor);
    Factor.f9 = factor;
    nannum     = nansum(isnan(Factor.f9.Data(end,:)));
    disp(['f9: ' datestr(Factor.f9.Dim1(end)) ',NaN����:' num2str(nannum)])

    AlphaScore = 1*Factor.f0 + 0.5*Factor.f1 + 0.2*Factor.f2 + 0.2*Factor.f3 + 0.25*Factor.f4 + 0.25*Factor.f5 + 0.25*Factor.f6 + 0.25*Factor.f7 + 0.25*Factor.f8 + 0.25*Factor.f9;
    AlphaScore = AlphaScore * iff(Factor.f0>0, 0.9, 1);

%   ##################
    AlphaScore2 = AlphaScore * iff((DF.AmtRank>100 & DF.AmtRank<2500 & DF.Pre_Close>5), NaN, 1);  
    AlphaScore  = AlphaScore * iff((DF.AmtRank>100 & DF.AmtRank<2500 & DF.Pre_Close>5), 1, NaN);
    AlphaRank   = xrank(-AlphaScore);
    AlphaScore  = iff(trmin(AlphaRank,{-4,0})<=50&trcount(AlphaRank,{-4 0})>=5&~isnan(AlphaScore2),AlphaScore2,AlphaScore);
    AlphaScore  = AlphaScore * DF.notST;
    AlphaRank   = xrank(-AlphaScore);
    
    m2 = AlphaRank;
    
    save([dirData '\m2.mat'],'m2');
    
    AlphaRank2 = transpose(AlphaRank); 
    AlphaRank2 = modify(AlphaRank2, 'Type',{'cell','numeric','double'}, 'Dim2',str2num(datestr(AlphaRank2.Dim2,'yyyymmdd'))');          %matlab����ת����excel����

    system('taskkill /F /IM EXCEL.EXE');
    TdT2Excel(compact(subset(AlphaRank2, AlphaRank2.Dim1, AlphaRank2.Dim2(end-9:end))),  'Save',[dirTrading '\500alpha_tradefile\m2_Trade' datestr(today(),'yyyymmdd') '.xlsx']);
    system('taskkill /F /IM EXCEL.EXE');
    
    clear a AlphaRank AlphaRank2 AlphaScore AlphaScore2 factor Factor factorscore m1 orthogonalize_normalizeAll_winsorize_FactorLab temp tempdata
    clear BETA BIAS DE2P DEP_FY DEP_FY2 DEP_FY3 DEP_FY_merge DROE EP_FY m2 QDROA RE2P ROAG RROE seasonality SUE SUOI SURI turnover turnover3d VOL VOL3M VOL5D wConsensus_NI 
    clear wConsensus wConsensus_NI_fy0 wConsensus_NI_fy1 weightTdT_fy0 weightTdT_fy1 wEst_DE2P wEst_DROE wEst_RE2P wEst_RROE wEst_SUE
    toc
    
    %% m3
    tic
    disp('����m3');
    load([dirData '\wConsensusFY0123.mat']);
    factor     = iff(isnan(wConsensus.NIs.f1.FY2),0,wConsensus.NIs.f1.FY2)*1.3 + ...
                 iff(isnan(wConsensus.NIs.f1.FY3),0,wConsensus.NIs.f1.FY3)*1.2 + ...
                 iff(isnan(wConsensus.NIs.f1.FY1),0,wConsensus.NIs.f1.FY1)*1.1 + ...
                 iff(isnan(wConsensus.NIs.f1.FY0),0,wConsensus.NIs.f1.FY0)*1.0 ;   

    factor = iff(isnan(wConsensus.NIs.f1.FY2)&isnan(wConsensus.NIs.f1.FY3)&...
                 isnan(wConsensus.NIs.f1.FY1)&isnan(wConsensus.NIs.f1.FY0), NaN, factor);      
  
    factor  = ttlast(factor,{Dim1+1,[Dim1(2:end);9999999]},Dim1,Dim2)*DF.notST;
    factor     = iff(factor>0, factor, NaN);
    factor     = xrank(factor)/xmax(xrank(factor));
    Factor.f0  = iff(isnan(factor), 0, factor);    %show(xcount(iff(Factor.f0==0,NaN,Factor.f0)));

    factor     = merge(wConsensus.NIs.f2.FY2, wConsensus.NIs.f2.FY1);
    factor     = ttlast(factor,{Dim1+1,[Dim1(2:end);9999999]},Dim1,Dim2);
    temp       = iff(abs(factor-1)<0.00001,1,NaN);
    factor     = xrank(factor)/xmax(xrank(factor));
    Factor.f1  = iff(isnan(factor)|temp==1, xmean(temp*factor), factor); %2019-5-7��,��Facotr.f1��NaN�Ĺ�ƱҲ��Ӱ���������ӵĴ��
    
    load([dirData '\factors_lqy\DROE.mat']);
    factor     = subset(DROE,       Dim1,Dim2);
    Factor.f2  = xrank(factor)/xmax(xrank(factor));   
    
    load([dirData '\factors_lqy\mom5d.mat']);    
    load([dirData '\factors_lqy\mom10d.mat']);
    factor     = 0.5 * subset(mom5d,       Dim1,Dim2) + 0.5 * subset(mom10d,       Dim1,Dim2);
    Factor.f3  = xrank(factor)/xmax(xrank(factor));   
    Factor.f3  = iff(Factor.f3>=0.2, 0.5, 0);
    
    load([dirData '\factors_lqy\RE2P.mat']);
    factor     = subset(RE2P,       Dim1,Dim2);
    Factor.f4  = xrank(factor)/xmax(xrank(factor)); 
    
    load([dirData '\factors_lqy\RROE.mat']);
    factor     = subset(RROE,       Dim1,Dim2);
    Factor.f5  = xrank(factor)/xmax(xrank(factor));    
    
    load([dirData '\factors_lqy\SUE.mat']);
    factor     = subset(SUE,       Dim1,Dim2);
    Factor.f6  = xrank(factor)/xmax(xrank(factor)); 

    AlphaScore = 1.00*Factor.f0 + 0.50*Factor.f1 + 0.25*Factor.f2 + 0.25*Factor.f3 + 0.25*Factor.f4 + 0.25*Factor.f5 + 0.25*Factor.f6 ;
    AlphaScore = AlphaScore * iff(Factor.f0>0, 0.9, 1) ;  

    load([dirData '\m1.mat']);
    load([dirData '\m2.mat']);
    
    m1 = subset(m1, Dim1, Dim2);
    m2 = subset(m2, Dim1, Dim2);
    AlphaScore = iff(isnan(m1)&isnan(m2)&DF.iftrade0==1&DF.iftrade1==1&DF.Pre_Close>=3&DF.AmtMean>=10000000, AlphaScore,NaN);
    AlphaRank = xrankII(-AlphaScore);
    
    m3 = AlphaRank;
    
    save([dirData '\m3.mat'],'m3');
    
    numStk = 30;    
    numOut = 150;
    average_days = 20;
    
    load([dirData '\KEEEEP2.mat']);
    KEEEEP2TdT = subset(KEEEEP2TdT, Dim1, Dim2);
    KEEEEP2TdT = iff(isnan(KEEEEP2TdT), 0, KEEEEP2TdT); KEEEEP2TdTdata = KEEEEP2TdT.Data;
    KEEEEP2 = zeros(size(KEEEEP2TdT.Data));
    
    for t0 = length(Dim1)-average_days-2:length(Dim1)

        disp(t0)
        KEEP = zeros(size(Dim1,1),size(Dim2,2));
        KEEP(t0,m3.Data(t0,:) <= numStk) = 1;


        for t = t0+1:min(t0+average_days-1,length(Dim1))
            if  nansum(AlphaRank.Data(t,:)>0) > 150                                    % �������t��ֵĹ�Ʊ������500��
                keep1    = KEEP(t-1,:).*double(AlphaRank.Data(t,:)<=numOut);              % ����ǰһ��t-1��ѡ�еģ����ں�һ��t������ǰ300�Ĺ�Ʊ  keep=0,1, NaN->0
                keep2    = KEEP(t-1,:).*double(AlphaRank.Data(t,:)>numOut).*double(isnan(DF.iftrade0.Data(t,:))); 

                keep     = keep1 + keep2;

                temp     = NaN(1,length(keep));
                temp(1,keep==0) = 1;                                                    % tempNan��keep�ķ�
                rankAdj = temp.*AlphaRank.Data(t,:).*double(DF.iftrade0.Data(t,:)==1).*double(DF.iftrade1.Data(t,:)==1);      % rankAdj�ǲ��ڱ��������еĹ�Ʊ�ĵ�������
                numAdj  = numStk - nansum(keep);                                        % numAdj��Ҫ������Ʊ������
                j=0;
                while numAdj>0                                                          % �ڲ��������������еĹ�Ʊ��������ߵ�ǰnumAdj��
                    j=j+1;
                    if  isempty(find(rankAdj==j))==0
                        keep(1, find(rankAdj==j)) = 1;
                        numAdj = numAdj - 1;
                    end
                end
                KEEP(t,:) = keep;
            else
                KEEP(t,:) = KEEP(t-1,:);
            end
        end        
        
        KEEEEP2 = KEEEEP2 + KEEP;
        
    end
    
    KEEEEP2TdTdata(end,:) = KEEEEP2(end,:);
    KEEEEP2TdT.Data = KEEEEP2TdTdata;    

    
    save([dirData '\KEEEEP2.mat'],'KEEEEP2TdT');
    
    clear a AlphaRank AlphaRank2 AlphaScore AlphaScore2 factor Factor factorscore m1 orthogonalize_normalizeAll_winsorize_FactorLab temp tempdata
    clear KEEEEP2 KEEEEP2TdT KEEEEP2TdTdata keep KEEP keep1 keep2 m2 m3 mom10d mom5d RE2P RROE SUE DROE
    toc
    
    %% m12
    tic
    disp('����m12');
    m1 = load([dirData '\m1.mat']); m1 = m1.(cell2mat(fields(m1))); 
    m2 = load([dirData '\m2.mat']); m2 = m2.(cell2mat(fields(m2))); 
    
    m1 = subset(m1, Dim1);
    m2 = subset(m2, Dim1);
      
    Multiple1 = iff(DF.Size<=800,1,iff(DF.Size<=1600,0.75,0.5));
    Multiple2 = iff(DF.AmtMean>=100000000,1,iff(DF.AmtMean>=50000000,0.75,0.5));
    Multiple = Multiple1 + Multiple2;
    
    numStk = 100;    
    rankOut1 = 500;
    rankOut2 = 105;
    average_days = 20;
    
    load([dirData '\KEEEEP1.mat']);
    KEEEEP1TdT = subset(KEEEEP1TdT, Dim1, Dim2);
    KEEEEP1TdT = iff(isnan(KEEEEP1TdT), 0, KEEEEP1TdT); KEEEEP1TdTdata = KEEEEP1TdT.Data;
    KEEEEP1 = zeros(size(KEEEEP1TdT.Data));
    
    for t0 = length(Dim1)-average_days-2:length(Dim1)

        disp(t0)
        KEEP = zeros(size(Dim1,1),size(Dim2,2));
        jj = 1;
        while(nansum(KEEP(t0,:))<numStk-2) && jj <= rankOut1
            KEEP(t0,m2.Data(t0,:) == jj) = Multiple.Data(t0,m2.Data(t0,:) == jj);
            jj = jj + 1;
        end

        for t = t0+1:min(t0+average_days-1,length(Dim1))
            if  nansum(m2.Data(t,:)>0) > 150                                    % �������t��ֵĹ�Ʊ������500��
                keep1    = KEEP(t-1,:).*double(m2.Data(t,:)<=rankOut1 | m1.Data(t,:)<=rankOut2);              % ����ǰһ��t-1��ѡ�еģ����ں�һ��t������ǰ300�Ĺ�Ʊ  keep=0,1, NaN->0
                keep2    = KEEP(t-1,:).*double(m2.Data(t,:)>rankOut1 & m1.Data(t,:)>rankOut2).*double(isnan(DF.iftrade0.Data(t,:)));

                keep     = keep1 + keep2;

                temp     = NaN(1,length(keep));
                temp(1,keep==0) = 1;                                                    % tempNan��keep�ķ�
                rankAdj = temp.*m2.Data(t,:).*double(DF.iftrade0.Data(t,:)==1).*double(DF.iftrade1.Data(t,:)==1);      % rankAdj�ǲ��ڱ��������еĹ�Ʊ�ĵ�������
                mulAdj  = temp.*Multiple.Data(t,:);
                numAdj  = numStk - nansum(keep);                                        % numAdj��Ҫ������Ʊ������
                j=0;
                while numAdj>0                                                          % �ڲ��������������еĹ�Ʊ��������ߵ�ǰnumAdj��
                    j=j+1;
                    if  isempty(find(rankAdj==j))==0
                        keep(1, find(rankAdj==j))=mulAdj(rankAdj==j);
                        numAdj = numAdj - mulAdj(rankAdj==j);
                    end
                    if j >= 1000
                        keep = KEEP(t-1,:);
                        break
                    end
                end

                KEEP(t,:) = keep;
            else
                KEEP(t,:) = KEEP(t-1,:);
            end
        end
        
        KEEEEP1 = KEEEEP1 + KEEP;
                
    end
    KEEEEP1TdTdata(end,:) = KEEEEP1(end,:);
    KEEEEP1TdT.Data = KEEEEP1TdTdata;
    
    save([dirData '\KEEEEP1.mat'],'KEEEEP1TdT');
    
    clear KEEEEP1 KEEEEP1TdT KEEEEP1TdTdata keep KEEP keep1 keep2 m1 m2 Multiple Multiple1 Multiple2 j jj
    toc
    
    %% m123
    tic
    disp('����m123');    
    
    m12 = load([dirData '\KEEEEP1.mat']); m12 = m12.(cell2mat(fields(m12)));
    m3  = load([dirData '\KEEEEP2.mat']); m3  = m3.(cell2mat(fields(m3)));  
        
    Multiple1 = iff(DF.Size<=800,1,iff(DF.Size<=1600,0.75,iff(DF.Size<=2400,0.5,0.15)));
    Multiple2 = iff(DF.AmtMean>=100000000,1,iff(DF.AmtMean>=50000000,0.75,iff(DF.AmtMean>=20000000,0.5,0.15)));
    Multiple = Multiple1 + Multiple2;   
    
    load([dirData '\KEEEEP1.mat']);
    load([dirData '\KEEEEP2.mat']);
    
    KEEEEP1TdT = subset(KEEEEP1TdT, Dim1, Dim2); KEEEEP1TdT = iff(isnan(KEEEEP1TdT), 0, KEEEEP1TdT);
    KEEEEP2TdT = subset(KEEEEP2TdT, Dim1, Dim2); KEEEEP2TdT = iff(isnan(KEEEEP2TdT), 0, KEEEEP2TdT);
    
    Port.Wei = KEEEEP1TdT + KEEEEP2TdT * Multiple;
    Port.Wei   = iff(Port.Wei>0, Port.Wei, NaN);
    Port.Wei   = Port.Wei/xsum(Port.Wei);
    Port.Wei   = iff(isnan(Port.Wei),  0, Port.Wei);                   
    
    PortadjWei = NaN(size(Port.Wei.Data));
    PortadjWei(1,:) = Port.Wei.Data(1,:); 
    for t = 2:size(Port.Wei.Data,1)
        
        PortadjWei(t,:)   = Port.Wei.Data(t,:);
        idx1 = find(abs(Port.Wei.Data(t,:) - PortadjWei(t-1,:))<=0.0002 & Port.Wei.Data(t,:)>0 & PortadjWei(t-1,:)>0);
        PortadjWei(t,idx1) = PortadjWei(t-1,idx1);
        
    end
    
    Portadj.Wei   = modify(Port.Wei, 'Data', PortadjWei);
    Portadj.Wei   = iff(Portadj.Wei>0, Portadj.Wei, 0);
    Portadj.Wgt   = tshift(Portadj.Wei,-1);                                           % ��������Ȩ��
    Portadj.Wgt   = iff(isnan(Portadj.Wgt),  0, Portadj.Wgt);                            % ��������Ȩ��
    Portadj.WgtL1 = tshift(Portadj.Wei,-2);                                           % ��������Ȩ��
    Portadj.WgtL1 = iff(isnan(Portadj.WgtL1),0, Portadj.WgtL1);                          % ��������Ȩ��   

    temp = iff(Portadj.Wgt==Portadj.WgtL1,  Ret.r1*Portadj.WgtL1,                                            ...
           iff(Portadj.Wgt> Portadj.WgtL1,  Ret.r1*Portadj.WgtL1 + (Ret.r2-0.001)*(Portadj.Wgt-Portadj.WgtL1),     ...
           iff(Portadj.Wgt< Portadj.WgtL1,  Ret.r1*Portadj.WgtL1 + (Ret.r3+0.002)*(Portadj.Wgt-Portadj.WgtL1),  NaN)));
    Nav = trsum(xsum(temp), {-inf,0});
    
    temp_pos = Ret.r1*Portadj.WgtL1;
    Nav_pos = trsum(xsum(temp_pos), {-inf,0}); Nav_pos.Dim2 = {'Nav_pos'};
    
    Nav = merge(Nav,Nav_pos,'unsort','Dim2');
        
    pos = subset(Portadj.Wei,Portadj.Wei.Dim1(end));
    pos = transpose(compact(iff(pos==0,NaN,pos)));
    pos = modify(pos, 'Type',{'cell','numeric','double'}, 'Dim2',str2num(datestr(pos.Dim2,'yyyymmdd'))');

    system('taskkill /F /IM EXCEL.EXE');
    TdT2Excel(compact(subset(Nav, Nav.Dim1(1:end))),     'Save',[dirTrading '\500alpha_tradefile\NAV'      datestr(today(),'yyyymmdd') '.xlsx']);
    TdT2Excel(compact(subset(pos, pos.Dim1, pos.Dim2)),  'Save',[dirTrading '\500alpha_tradefile\Position' datestr(today(),'yyyymmdd') '.xlsx']);
    
    toc
    
end

function checkDim1(TdTin)
    num = nansum(isnan(TdTin.Data(end,:)));
    disp([TdTin.Name ' : ' datestr(TdTin.Dim1(end)) ' , NaN����: ' num2str(num)]);
end


    

    
    
    
    

    

    
    
    
    