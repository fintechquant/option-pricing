% update_wdbTable1571_v2(); ÿ���Զ���ʱ���±�1571
% update_wdbTable1571_v2(2); ����һ�α�1571 ͨ��load Table 1571
% update_wdbTable1571_v2(3); ����һ�α�1571 ͨ��load Table ASHAREEARNINGEST
% cd('\\PINFU-WS-01\Production\zhangf\windEstimate');
function update_wdbTable1571_v2(key)   

    if nargin == 0
        key = 1;
    end

    if key == 1
        while(1)
            t1 = floor(today()) + 8/24  + 10/24/60;
            t2 = floor(today()) + 8/24  + 25/24/60;
            t3 = floor(today()) + 9/24  + 10/24/60;
            t4 = floor(today()) + 12/24 + 30/24/60;
            t5 = floor(today()) + 14/24 + 30/24/60;
            t6 = floor(today()) + 19/24;
            t7 = floor(today()) + 23/24;
            timepoint = [t1,t2,t3,t4,t5,t6,t7];
            for i = timepoint
                if i > now()
                    disp(['next update time is ' datestr(i,'yyyymmdd HH:MM:SS')]);
                    pauseTill(i);
                    update_wdbTable1571_v2(3);
                end
            end
            pauseTill(today()+1+1/24); %���ո���ȫ����ɺ�,�ȵ���һ��Ȼ���ٽ��и���
        end
    end

    if key == 3

        dirRoot = getDir('Production');     dirData = [dirRoot '\Data\data2github'];
        load([dirData '\wdbTable1571.mat']);

        % read new rows
        tic;
        date1     = today()-25;
        date2     = today()+1;
        saveflag  = 0;
        
        wdbTable1571A = ASHAREEARNINGEST(date1, date2); 
        wdbTable1571A.Properties.VariableNames = wdbTable1571.Properties.VariableNames;
        wdbTable1571A = sortrows(wdbTable1571A, {'F16_1090','F2_1571','F29_1571','F4_1571'});
        wdbTable1571A(wdbTable1571A.F4_1571<20191231,:) = []; %�����д�����������
        
        if size(wdbTable1571A,1)>0
           Js    = [7:11 18:27 29:30 33:42 44:50];
           xx    = table2array(wdbTable1571A(:,Js));  xx(isnan(xx)) = -999.888;   wdbTable1571A(:,Js) = array2table(xx);
           yy    = table2array(wdbTable1571(:,Js));   yy(isnan(yy)) = -999.888;   wdbTable1571(:,Js)  = array2table(yy);    
           Ls    = [1 5:7 9:11 18:26 29:30 36:41 44:49];
           idx_a = ismember(wdbTable1571A(:,Ls),wdbTable1571(:,Ls),'rows');   % exclude sqlRunTime and sqlDeleteTime in comparison
           if sum(1-idx_a)>0
              wdbTable1571 = [wdbTable1571; wdbTable1571A(~idx_a,:)];
              disp(['read ' num2str(sum(1-idx_a)) ' rows in ' num2str(toc,'%9.2f') ' sec' ]);
              saveflag = 1;
           else
              disp(['read'                      ' 0 rows in ' num2str(toc,'%9.2f') ' sec' ]);
           end
        else
           disp(['read'                      '0 rows in ' num2str(toc,'%9.2f') ' sec with errors' ]);
        end
        
        if saveflag == 1
            disp('####Saving file now........#####');
            dirCopy = ['copy ' dirData];
            save([dirData '\wdbTable1571.mat']   , 'wdbTable1571');
            uniqueid = wdbTable1571.OB_OBJECT_ID;
            save([dirData '\wdbTable1571_id.mat'],'uniqueid');
        end

       if key == 2
           % delete missing rows
           tic;
           date1           = datenum('20181230'  ,'yyyymmdd');
           date2           = datenum('20231230'  ,'yyyymmdd');
           saveflag  = 0;
%          DataBaseFetcher_local.getDataFromAny('wind','SELECT TOP 1 * FROM TB_OBJECT_1571', true);
           DataBaseFetcher.getDataFromAny('wind','SELECT TOP 1 * FROM TB_OBJECT_1571', true);
           disp('validation query test passed');
           wdbTable1571B   = wdbTable1571Sql(date1, date2, 2);

           if size(wdbTable1571B,1)>0
               Js    = [7:11 18:27 29:30 33:42 44:50];
               xx    = table2array(wdbTable1571B(:,Js));  xx(isnan(xx)) = -999.888;   wdbTable1571B(:,Js) = array2table(xx);
               yy    = table2array(wdbTable1571(:,Js));   yy(isnan(yy)) = -999.888;   wdbTable1571(:,Js)  = array2table(yy); 
               idx_d = ismember(wdbTable1571(:,1:end-2),wdbTable1571B(:,1:end-2),'rows');   % exclude sqlRunTime and sqlDeleteTime in comparison
               idx_e = strcmp(wdbTable1571.sqlDeleteTime,'');
               idx_f = wdbTable1571.F4_1571 >= str2double(datestr(date1,'yyyymmdd'));
               if sum((~idx_d)&idx_e&idx_f)>0
                  wdbTable1571.sqlDeleteTime((~idx_d)&idx_e&idx_f) = {datestr(now(),'yyyy-mm-dd HH:MM:SS.0')};
                  disp(['delete ' num2str(sum((~idx_d)&idx_e&idx_f)) ' rows in ' num2str(toc,'%9.2f') ' sec' ]);
                  saveflag = 1;
               else
                  disp(['delete'                      ' 0 rows in ' num2str(toc,'%9.2f') ' sec' ]);
               end 
           end
           
           if saveflag == 1
                disp('####Saving file now........#####');
                dirCopy = ['copy ' dirData];
%               system([dirCopy  'wdbTable1571.mat ' ' \\PINFU-WS-01\Production\DataCopy\wdbTable1571.mat' ]);
                save([dirData '\wdbTable1571A.mat'], 'wdbTable1571');
            end
       end

    end
      
end

function sqlTable1571 = ASHAREEARNINGEST(date1, date2)
    
    sqlStmt = [' SELECT * FROM [WindFileSync].[dbo].[ASHAREEARNINGEST] '            char(10)...
              'WHERE OPDATE >= ''' [datestr(date1, 'yyyymmdd') ' 00:00:00'] ''''    char(10)...
              ' and OPDATE <=''' [datestr(date2, 'yyyymmdd') ' 23:59:59'] ''''      char(10) ];
          
    disp(sqlStmt);

    try
%     sqlData           = DataBaseFetcher_local.getDataFromAny('wind',sqlStmt, true);
      sqlData           = DataBaseFetcher.getDataFromAny('wind',sqlStmt, true);
      sqlTable1571(:,1) = cellfun(@(x) x(1:6) ,sqlData(2:end,2), 'UniformOutput', false);
      sqlTable1571(:,3) = sqlData(2:end,1);
      sqlTable1571(:,5) = sqlData(2:end,4);
      sqlTable1571(:,6) = sqlData(2:end,5);
      sqlTable1571(:,7) = cellfun(@(x) str2num(x), sqlData(2:end,7), 'UniformOutput', false);
      sqlTable1571(:,8) = cellfun(@(x) str2num(x), sqlData(2:end,6), 'UniformOutput', false);
      sqlTable1571(:,9) = sqlData(2:end,8);
      sqlTable1571(:,10) = sqlData(2:end,10);
      sqlTable1571(:,11) = sqlData(2:end,9);
      sqlTable1571(:,14) = sqlData(2:end,43);
      sqlTable1571(:,18) = sqlData(2:end,15);
      sqlTable1571(:,19) = sqlData(2:end,16);
      sqlTable1571(:,20) = sqlData(2:end,11);
      sqlTable1571(:,21) = sqlData(2:end,12);
      sqlTable1571(:,22) = sqlData(2:end,17);
      sqlTable1571(:,23) = sqlData(2:end,18);
      sqlTable1571(:,24) = sqlData(2:end,19);
      sqlTable1571(:,25) = sqlData(2:end,20);
      sqlTable1571(:,26) = num2cell(NaN(size(sqlData,1)-1,1));
      sqlTable1571(:,27) = {1};
      sqlTable1571(:,29) = sqlData(2:end,13);
      sqlTable1571(:,30) = {1};
      sqlTable1571(:,33) = {33};
      sqlTable1571(:,34) = {33};
      sqlTable1571(:,35) = cellfun(@(x) str2num(x), sqlData(2:end,14), 'UniformOutput', false);
      sqlTable1571(:,36) = sqlData(2:end,22);
      sqlTable1571(:,37) = sqlData(2:end,23);
      sqlTable1571(:,38) = {-999.888};
      sqlTable1571(:,39) = sqlData(2:end,41);
      sqlTable1571(:,40) = sqlData(2:end,25);
      sqlTable1571(:,41) = sqlData(2:end,26);
      sqlTable1571(:,42) = {-999.888};
      sqlTable1571(:,43) = sqlData(2:end,37);
      sqlTable1571(:,44) = sqlData(2:end,27);
      sqlTable1571(:,45) = sqlData(2:end,28);
      sqlTable1571(:,46) = sqlData(2:end,29);
      sqlTable1571(:,47) = sqlData(2:end,30);
      sqlTable1571(:,48) = sqlData(2:end,31);
      sqlTable1571(:,49) = sqlData(2:end,32);
      sqlTable1571(:,50) = cellfun(@(x) str2num(datestr(datenum(x,'yyyymmdd')+183,'yyyymmdd')), sqlData(2:end,14), 'UniformOutput', false);
      sqlTable1571(:,51) = sqlData(2:end,43);
      sqlTable1571(:,52) = {''};
      sqlTable1571 = cell2table(sqlTable1571);
      
      disp(['sqlTable1571 has ' num2str(size(sqlTable1571,1)-1) ' rows']);
    catch
      sqlTable1571 = [];
      disp('sqlTable1571 cannot be created');
    end      
          
end