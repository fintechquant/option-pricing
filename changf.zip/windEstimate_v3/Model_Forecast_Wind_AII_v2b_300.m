function Model_Forecast_Wind_AII_v2b_300
% one factor quickly test

    BeginDate   = '20121231';                                                     %  '20171123'
    HedgeIdx    = {'000905.SH'};   
%% LoadData

    dirRoot = getDir('Production');       dirData = [dirRoot '\Data']            % 'Production'  'D:\PinFu-WS-01\Production'
    dirTrading = [dirData '\Trading']
    
    load([dirData '\wIdx.mat']);    
    load([dirData '\wPrc_Stocks.mat']);
    load([dirData '\wPrc_Indices.mat']);
    load([dirData '\wPrc_Events.mat']);
    load([dirData '\wConsensusFY0123.mat']);
    load([dirData '\CDSys_Var1.mat']);

%% prepare DF
%   Temp1        = merge(wPrc_Stocks.Open,wPrc_Indices.Open); 
%   Temp1        = CDSys_Var.Type_Price_Name_Twap0935_FormTime_0930_0935;      % it includes indices' prices; 
%   Temp1        = CDSys_Var.Type_Price_Name_Twap1000_FormTime_0930_1000; 
%   Temp1        = CDSys_Var.Type_Price_Name_Twap1430_FormTime_1400_1430; 
    clear DF;
    DF.IntraDay0 = CDSys_Var.Type_Price_Name_Twap0930_FormTime_0930_0930;
    DF.IntraDay1 = CDSys_Var.Type_Price_Name_Twap0935_FormTime_0931_0935;      % 'Open' 'Open';  'AVClose'
    DF.IntraDay2 = CDSys_Var.Type_Price_Name_Twap1430_FormTime_1400_1430;
    Dim1         = wPrc_Stocks.Close.Dim1;
    Dim1         = Dim1(Dim1>=datenum(BeginDate,'yyyymmdd'));  
    Dim2         = unique([wPrc_Stocks.Close.Dim2,  wPrc_Indices.Close.Dim2]);
    
    DF.IntraDay0 = subset(DF.IntraDay0,          Dim1,Dim2);
    DF.IntraDay1 = subset(DF.IntraDay1,          Dim1,Dim2);
    DF.IntraDay2 = subset(DF.IntraDay2,          Dim1,Dim2);
    DF.Open      = subset(merge(wPrc_Stocks.Open,      wPrc_Indices.Open),      Dim1,Dim2); 
    DF.Close     = subset(merge(wPrc_Stocks.Close,     wPrc_Indices.Close),     Dim1,Dim2); 
    DF.Pre_Close = subset(merge(wPrc_Stocks.Pre_Close, wPrc_Indices.Pre_Close), Dim1,Dim2); 
    DF.AdjFactor = subset(wPrc_Stocks.AdjFactor, Dim1,Dim2); 
    DF.Volume    = subset(wPrc_Stocks.Volume,    Dim1,Dim2); 
    DF.Amt       = subset(wPrc_Stocks.Amt,       Dim1,Dim2); 
    DF.AmtRank   = xrank(-ttmean(DF.Amt,{-60,0}, Dim1,Dim2));
    DF.AmtMean    = trmean(DF.Amt, {-9,0}, Dim1, Dim2);
    
    DF.iftrade0  = iff(tshift(DF.Amt,1)>0, 1, NaN);                                                                   % ������Ҫ����
    tempdata = DF.iftrade0.Data; tempdata(end,:) = tempdata(end-1,:); DF.iftrade0.Data = tempdata;
    DF.iftrade1  = tshift(DF.Open/DF.Pre_Close-1,1);                                                                  % ���տ����Ƿ�
    DF.iftrade1  = iff(DF.iftrade1>-0.08 & DF.iftrade1<0.08, 1, NaN);                                                 % ���տ��̷��ǵ�ͣ
    tempdata = DF.iftrade1.Data; tempdata(end,:) = ones(1,length(tempdata(end,:))); DF.iftrade1.Data = tempdata;
 %  DF.iftrade1  = DF.iftrade1 * iff(tshift(DF.IntraDay0/DF.Open-1,1)>-0.28 & tshift(DF.IntraDay0/DF.Open-1,1)<0.21, 1, NaN);    % ���տ���->9;30
    DF.notST     = ttlast(merge(wPrc_Events.CarryoutSpecialTreatment,iff(wPrc_Events.CancelSpecialTreatment==1,0,NaN)), {-inf,0}, Dim1, Dim2);
    DF.notST     = iff(DF.notST==1, NaN, 1);
    DF.Size       = xrankII(-log(subset(wPrc_Stocks.Float_A_Shares, Dim1, Dim2) * subset(wPrc_Stocks.Close, Dim1, Dim2)));
    
    Ret.r1 = DF.Close/DF.Pre_Close;   Ret.r1 = Ret.r1 - subset(Ret.r1, Dim1, HedgeIdx);     % Excess return
    Ret.r2 = DF.Close/DF.IntraDay1;   Ret.r2 = Ret.r2 - subset(Ret.r2, Dim1, HedgeIdx);     % Excess return  Open  IntraDay1
    Ret.r3 = DF.Close/DF.IntraDay2;   Ret.r3 = Ret.r3 - subset(Ret.r3, Dim1, HedgeIdx);     % Excess return  Close IntraDay2
    
%% Factor Create

    factor     = iff(isnan(wConsensus.NIs.f1.FY2),0,wConsensus.NIs.f1.FY2)*1.3 + ...
                 iff(isnan(wConsensus.NIs.f1.FY3),0,wConsensus.NIs.f1.FY3)*1.2 + ...
                 iff(isnan(wConsensus.NIs.f1.FY1),0,wConsensus.NIs.f1.FY1)*1.1 + ...
                 iff(isnan(wConsensus.NIs.f1.FY0),0,wConsensus.NIs.f1.FY0)*1.0 ;   

    factor = iff(isnan(wConsensus.NIs.f1.FY2)&isnan(wConsensus.NIs.f1.FY3)&...
                 isnan(wConsensus.NIs.f1.FY1)&isnan(wConsensus.NIs.f1.FY0), NaN, factor);      
  
    factor  = ttlast(factor,{Dim1+1,[Dim1(2:end);9999999]},Dim1,Dim2)*DF.notST;
    factor     = iff(factor>0, factor, NaN);
    factorscore = factor * DF.iftrade0 * DF.iftrade1;
    factor     = xrank(factor)/xmax(xrank(factor));
    Factor.f0  = iff(isnan(factor), 0, factor);    %show(xcount(iff(Factor.f0==0,NaN,Factor.f0)));
    nannum     = nansum(isnan(Factor.f0.Data(end,:)));
    disp(['f0: ' datestr(Factor.f0.Dim1(end)) ',NaN����:' num2str(nannum)])

    factor     = merge(wConsensus.NIs.f2.FY2, wConsensus.NIs.f2.FY1);
    factor     = ttlast(factor,{Dim1+1,[Dim1(2:end);9999999]},Dim1,Dim2);
    temp       = iff(abs(factor-1)<0.00001,1,NaN);
    factor     = xrank(factor)/xmax(xrank(factor));
    Factor.f1  = iff(isnan(factor)|temp==1, xmean(temp*factor), factor); %2019-5-7��,��Facotr.f1��NaN�Ĺ�ƱҲ��Ӱ���������ӵĴ��
    nannum     = nansum(isnan(Factor.f1.Data(end,:)));
    disp(['f1: ' datestr(Factor.f1.Dim1(end)) ',NaN����:' num2str(nannum)])
    
    load([dirData '\factors_lqy\SUE.mat']); 
    wEst_SUE = subset(SUE, Dim1, Dim2);
    wEst_SUE = xrankII(wEst_SUE) / xmax(xrankII(wEst_SUE));
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Momentum1_SUE.mat']);
    SUE = subset(SUE, Dim1, Dim2);
    SUE = xrankII(SUE) / xmax(xrankII(SUE));
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Momentum1_SURI.mat']); 
    SURI = subset(SURI, Dim1, Dim2);
    SURI = xrankII(SURI) / xmax(xrankII(SURI));
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Momentum1_SUOI.mat']); 
    SUOI = subset(SUOI, Dim1, Dim2);
    SUOI = xrankII(SUOI) / xmax(xrankII(SUOI));
    
    factor = 1/6 * iff(isnan(SUE),0.5,SUE) + 1/6 * iff(isnan(wEst_SUE),0.5,wEst_SUE) + 1/3 * iff(isnan(SUOI),0.5,SUOI) + 1/3 * iff(isnan(SURI),0.5,SURI);
    Factor.f2 = factor;
    
    load([dirData '\factors_lqy\RROE.mat']); 
    wEst_RROE = subset(RROE, Dim1, Dim2);
    wEst_RROE = xrankII(wEst_RROE) / xmax(xrankII(wEst_RROE));
    load([dirData '\factors_lqy\DROE.mat']); 
    wEst_DROE = subset(DROE, Dim1, Dim2);
    wEst_DROE = xrankII(wEst_DROE) / xmax(xrankII(wEst_DROE));    
    factor = 1/2 * iff(isnan(wEst_RROE),0.5,wEst_RROE) + 1/2 * iff(isnan(wEst_DROE),0.5,wEst_DROE);
    Factor.f3 = factor;   
    
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Sentiment_VOL.mat']); 
    VOL = subset(VOL, Dim1, Dim2);
    VOL = xrankII(VOL) / xmax(xrankII(VOL));    
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Sentiment_VOL5D.mat']); 
    VOL5D = subset(VOL5D, Dim1, Dim2);
    VOL5D = xrankII(VOL5D) / xmax(xrankII(VOL5D));     
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Sentiment_VOL3M.mat']);  
    VOL3M = subset(VOL3M, Dim1, Dim2);
    VOL3M = xrankII(VOL3M) / xmax(xrankII(VOL3M));     
    load([dirData '\factors_lqy\turnover3d.mat']); 
    turnover = subset(turnover3d, Dim1, Dim2);
    turnover = xrankII(turnover) / xmax(xrankII(turnover)); 
    factor = 1/4 * iff(isnan(VOL),0.5,VOL) + 1/4 * iff(isnan(VOL5D),0.5,VOL5D) + 1/4 * iff(isnan(VOL3M),0.5,VOL3M) + 1/4 * iff(isnan(turnover),0.5,turnover);
    Factor.f4 = factor;   
    
    load([dirData '\factors_lqy\RE2P.mat']);
    wEst_RE2P = subset(RE2P, Dim1, Dim2);
    wEst_RE2P = xrankII(wEst_RE2P) / xmax(xrankII(wEst_RE2P));     
    load([dirData '\factors_lqy\DE2P.mat']); 
    wEst_DE2P = subset(DE2P, Dim1, Dim2);
    wEst_DE2P = xrankII(wEst_DE2P) / xmax(xrankII(wEst_DE2P));  
    
    %DEP
    wConsensus_NI = wConsensus.NIs;
    wConsensus_NI_fy0 = ttlast(wConsensus_NI.avg.FY0,  {Dim1+1,[Dim1(2:end);9999999]},Dim1,Dim2);
    wConsensus_NI_fy1 = ttlast(wConsensus_NI.avg.FY1,  {Dim1+1,[Dim1(2:end);9999999]},Dim1,Dim2);
    weightTdT_fy0     = iff(monthTdT(wConsensus_NI_fy0)>3, (16-monthTdT(wConsensus_NI_fy0))/12, (4-monthTdT(wConsensus_NI_fy0))/12);
    weightTdT_fy1     = abs(1 - weightTdT_fy0);
    EP_FY             = weightTdT_fy0 * wConsensus_NI_fy0 + weightTdT_fy1 * wConsensus_NI_fy1 ;
    EP_FY             = subset(EP_FY, Dim1, Dim2) * 10000 / (subset(wPrc_Stocks.Total_Shares,Dim1,Dim2) * subset(iff(isnan(wPrc_Stocks.Close)==1,wPrc_Stocks.Pre_Close,wPrc_Stocks.Close),Dim1,Dim2));
    EP_FY.Name        = 'EP_FY';

    DEP_FY  = EP_FY / tshift(EP_FY,-60) - 1;      DEP_FY.Name  = 'DEP_FY_v1';
    DEP_FY2 = EP_FY / tshift(EP_FY,-40) - 1;      DEP_FY2.Name = 'DEP_FY_v2';
    DEP_FY3 = EP_FY / tshift(EP_FY,-20) - 1;      DEP_FY3.Name = 'DEP_FY_v3';

    DEP_FY_merge = xrankII(DEP_FY) / xmax(xrankII(DEP_FY)) + xrankII(DEP_FY2) / xmax(xrankII(DEP_FY2)) + xrankII(DEP_FY3) / xmax(xrankII(DEP_FY3));
    a = factor_parse(DEP_FY_merge,1);   DEP_FY_merge = a.wins_norm_sizeANDindusNeutral2;    DEP_FY_merge.Name = 'DEP_FY_merge';
    
    DEP_FY_merge = subset(DEP_FY_merge, Dim1, Dim2);
    DEP_FY_merge = xrankII(DEP_FY_merge) / xmax(xrankII(DEP_FY_merge));     
    factor = 1/4 * iff(isnan(wEst_RE2P),0.5,wEst_RE2P) + 1/4 * iff(isnan(wEst_DE2P),0.5,wEst_DE2P) + 1/2 * iff(isnan(DEP_FY_merge),0.5,DEP_FY_merge) ;
    Factor.f5 = factor;   
    nannum     = nansum(isnan(Factor.f5.Data(end,:)));
    disp(['f5: ' datestr(Factor.f5.Dim1(end)) ',NaN����:' num2str(nannum)])
    
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Quality_QDROA.mat']); 
    QDROA = subset(QDROA, Dim1, Dim2);
    QDROA = xrankII(QDROA) / xmax(xrankII(QDROA));     
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Growth_ROAG.mat']); 
    ROAG = subset(ROAG, Dim1, Dim2);
    ROAG = xrankII(ROAG) / xmax(xrankII(ROAG)); 
    factor = 1/2 * iff(isnan(QDROA),0.5,QDROA) + 1/2 * iff(isnan(ROAG),0.5,ROAG);
    Factor.f6 = factor;     
    nannum     = nansum(isnan(Factor.f6.Data(end,:)));
    disp(['f6: ' datestr(Factor.f6.Dim1(end)) ',NaN����:' num2str(nannum)])
    
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Sentiment_BETA.mat']); 
    BETA = subset(BETA, Dim1, Dim2);
    BETA = xrankII(BETA,40);
    BETA = iff(BETA>=10,10,BETA)/40; 
    BETA = iff(isnan(BETA), 10/40, BETA);
    Factor.f7 = BETA;     
    nannum     = nansum(isnan(Factor.f7.Data(end,:)));
    disp(['f7: ' datestr(Factor.f7.Dim1(end)) ',NaN����:' num2str(nannum)])
    
    load([dirData '\factors_zyd\orthogonalize_normalizeAll_winsorize_AdT2_Momentum2_BIAS.mat']);
    BIAS = subset(BIAS, Dim1, Dim2);
    BIAS = xrankII(BIAS) / xmax(xrankII(BIAS));
    BIAS = iff(isnan(BIAS), 0.5, BIAS);
    Factor.f8 = BIAS;
    nannum     = nansum(isnan(Factor.f8.Data(end,:)));
    disp(['f8: ' datestr(Factor.f8.Dim1(end)) ',NaN����:' num2str(nannum)])
    
    load([dirData '\factors_lqy\seasonality2.mat']);
    factor = subset(a, Dim1, Dim2);
    factor = xrankII(-factor,20);
    factor = iff(factor>=10,10,factor)/10;
    factor = iff(isnan(factor), 0, factor);
    Factor.f9 = factor;
    nannum     = nansum(isnan(Factor.f9.Data(end,:)));
    disp(['f9: ' datestr(Factor.f9.Dim1(end)) ',NaN����:' num2str(nannum)])

    AlphaScore = 1*Factor.f0 + 0.5*Factor.f1 + 0.2*Factor.f2 + 0.2*Factor.f3 + 0.25*Factor.f4 + 0.25*Factor.f5 + 0.25*Factor.f6 + 0.25*Factor.f7 + 0.25*Factor.f8 + 0.25*Factor.f9;
    AlphaScore = AlphaScore * iff(Factor.f0>0, 0.9, 1);

%   ##################

    AlphaScore2 = AlphaScore * iff((DF.AmtRank>100 & DF.AmtRank<2500 & DF.Pre_Close>5), NaN, 1);  
    AlphaScore  = AlphaScore * iff((DF.AmtRank>100 & DF.AmtRank<2500 & DF.Pre_Close>5), 1, NaN);
    AlphaRank   = xrank(-AlphaScore);
    AlphaScore  = iff(trmin(AlphaRank,{-4,0})<=50&trcount(AlphaRank,{-4 0})>=5&~isnan(AlphaScore2),AlphaScore2,AlphaScore);
    AlphaRank   = xrank(-AlphaScore);
    
    Multiple1 = iff(DF.Size<=800,1,iff(DF.Size<=1600,0.75,0.5));
    Multiple2 = iff(DF.AmtMean>=100000000,1,iff(DF.AmtMean>=50000000,0.75,0.5));
    Multiple = Multiple1 + Multiple2;
    
    numStk = 50;     t0 = 1;
    KEEP = zeros(size(AlphaRank.Data));
    KEEP(t0,AlphaRank.Data(1,:)<=numStk) = 1;
    rankOut = 300;

    for t = t0+1:length(Dim1)
        if  nansum(AlphaRank.Data(t,:)>0) > 150                                    % �������t��ֵĹ�Ʊ������500��
            keep1    = KEEP(t-1,:).*double(AlphaRank.Data(t,:)<=rankOut);              % ����ǰһ��t-1��ѡ�еģ����ں�һ��t������ǰ300�Ĺ�Ʊ  keep=0,1, NaN->0
            keep2    = KEEP(t-1,:).*double(AlphaRank.Data(t,:)>rankOut).*double(isnan(DF.iftrade0.Data(t,:))); 
            
            keep     = keep1 + keep2;
            
            temp     = NaN(1,length(keep));
            temp(1,keep==0) = 1;                                                    % tempNan��keep�ķ�
            rankAdj = temp.*AlphaRank.Data(t,:).*double(DF.iftrade0.Data(t,:)==1).*double(DF.iftrade1.Data(t,:)==1);      % rankAdj�ǲ��ڱ��������еĹ�Ʊ�ĵ�������
            mulAdj  = temp.*Multiple.Data(t,:);
            numAdj  = numStk - nansum(keep);                                        % numAdj��Ҫ������Ʊ������
            j=0;
            while numAdj>0                                                          % �ڲ��������������еĹ�Ʊ��������ߵ�ǰnumAdj��
                j=j+1;
                if  isempty(find(rankAdj==j))==0
                    keep(1, find(rankAdj==j))=mulAdj(rankAdj==j);
                    numAdj = numAdj - mulAdj(rankAdj==j);
                end
                if j >= 1000
                    keep = KEEP(t-1,:);
                    break
                end
            end
            KEEP(t,:) = keep;
        else
            KEEP(t,:) = KEEP(t-1,:);
        end
    end        
   
    Port.Wei   = modify(AlphaRank, 'Data', KEEP);
    Port.Wei   = iff(Port.Wei>0, Port.Wei, NaN);
    Port.Wei   = Port.Wei/xsum(Port.Wei);
    Port.Wei   = iff(isnan(Port.Wei),  0, Port.Wei);                            
    Port.Wgt   = tshift(Port.Wei,-1);                                           % ��������Ȩ��
    Port.Wgt   = iff(isnan(Port.Wgt),  0, Port.Wgt);                            % ��������Ȩ��
    Port.WgtL1 = tshift(Port.Wei,-2);                                           % ��������Ȩ��
    Port.WgtL1 = iff(isnan(Port.WgtL1),0, Port.WgtL1);                          % ��������Ȩ��   
    
    indu = subset(wPrc_Stocks.Industry_Citic, Dim1, Dim2);
    fixedwgt  = ttlast(iff(isnan(wIdx.CSI300),-9999,wIdx.CSI300), {-inf 0}, Dim1, Dim2); fixedwgt = iff(fixedwgt==-9999, NaN, fixedwgt); 
    
    wgt1 = iff(indu==5022|indu==5021|indu==5018|indu==5019, fixedwgt, 0);
    wgt1 = iff(isnan(wgt1),0,wgt1);
    
    Port2.Wei = Port.Wei * (1 - xsum(wgt1));
    idx = find(strcmp(Port2.Wei.Dim2,'000016.SH'));  ih50 = xsum(Port2.Wei)*0.8; ih50 = ih50.Data;
    Port2.Wei = Port2.Wei * 0.8 + wgt1;
    tempdata = Port2.Wei.Data; tempdata(:,idx) = ih50; Port2.Wei.Data = tempdata;
    
    Ret2.r1 = DF.Close/DF.Pre_Close;   Ret2.r1 = Ret2.r1 - subset(Ret2.r1, Dim1, {'000300.SH'});     % Excess return
    Ret2.r2 = DF.Close/DF.IntraDay1;   Ret2.r2 = Ret2.r2 - subset(Ret2.r2, Dim1, {'000300.SH'});     % Excess return  Open  IntraDay1
    Ret2.r3 = DF.Close/DF.IntraDay2;   Ret2.r3 = Ret2.r3 - subset(Ret2.r3, Dim1, {'000300.SH'});     % Excess return  Close IntraDay2
    
    Port2.Wei   = iff(isnan(Port2.Wei),  0, Port2.Wei);
    Port2.Wgt   = tshift(Port2.Wei,-1);
    Port2.Wgt   = iff(isnan(Port2.Wgt),  0, Port2.Wgt);
    Port2.WgtL1 = tshift(Port2.Wgt,-1);                                           % ��������Ȩ��
    Port2.WgtL1 = iff(isnan(Port2.WgtL1),0, Port2.WgtL1);                          % ��������Ȩ�� 
    temp = iff(Port2.Wgt==Port2.WgtL1,  Ret2.r1*Port2.WgtL1,                                            ...
           iff(Port2.Wgt> Port2.WgtL1,  Ret2.r1*Port2.WgtL1 + (Ret2.r2-0.001)*(Port2.Wgt-Port2.WgtL1),     ...
           iff(Port2.Wgt< Port2.WgtL1,  Ret2.r1*Port2.WgtL1 + (Ret2.r3+0.002)*(Port2.Wgt-Port2.WgtL1),  NaN)));
    wAnalystNAV.(['m1_Mix' num2str(numStk)]) = trsum(xsum(temp), {-inf,0});
    Nav = wAnalystNAV.(['m1_Mix' num2str(numStk)]); 
    
    temp_pos = Ret2.r1*Port2.WgtL1;
    wAnalystNAV.(['m1_Mix' num2str(numStk) '_pos']) = trsum(xsum(temp_pos), {-inf,0});
    Nav_pos = wAnalystNAV.(['m1_Mix' num2str(numStk) '_pos']); Nav_pos.Dim2 = {'Nav_pos'};
    
    Nav = merge(Nav,Nav_pos,'unsort','Dim2');
        
    pos = subset(Port2.Wei,Port2.Wei.Dim1(end),wPrc_Stocks.Close.Dim2);
    pos = transpose(compact(iff(pos==0,NaN,pos)));
    pos = modify(pos, 'Type',{'cell','numeric','double'}, 'Dim2',str2num(datestr(pos.Dim2,'yyyymmdd'))');

    TdT2Excel(compact(subset(Nav, Nav.Dim1(1:end))),     'Save',[dirTrading '\300alpha_tradefile\NAV'      datestr(today(),'yyyymmdd') '.xlsx']);
    TdT2Excel(compact(subset(pos, pos.Dim1, pos.Dim2)),  'Save',[dirTrading '\300alpha_tradefile\Position' datestr(today(),'yyyymmdd') '.xlsx']); 
    

  
end

function checkDim1(TdTin)
    num = nansum(isnan(TdTin.Data(end,:)));
    disp([TdTin.Name ' : ' datestr(TdTin.Dim1(end)) ' , NaN����: ' num2str(num)]);
end


    

    
    
    
    

    

    
    
    
    